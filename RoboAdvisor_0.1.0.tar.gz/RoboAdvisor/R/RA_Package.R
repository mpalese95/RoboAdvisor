#######################################################################################
#######################################################################################

#  title: "Thesis: Implementing Betterment Strategy - ETF Selection"
#  author: Mattia Palese
#  last date updated: 17 November 2019

#######################################################################################
#######################################################################################

#Program inputs

# Years <- 5
# Simulations <- 1000
# Investor_Goal <- 1
# Age_Investor = 40
# Initial_Investment = 100000 #100'000 USD
# Yearly_Contribution = 8500 #8'500 USD - Assumes investing rate of 7% of gross income
# Sustainable = TRUE
# Lambda = 3.5
# Comparison = TRUE

#######################################################################################
#######################################################################################


allocation <- function(Years=5, Simulations=1000,Investor_Goal=1,Age_Investor=40,
                       Initial_Investment=100000,Yearly_Contribution=8500,Sustainable=FALSE,Lambda=3.5,Comparison=TRUE){


  if(isTRUE(Years>40)) {Years <- 40}

  if(isTRUE(Investor_Goal==1)) {Investor_Goal=1
  } else if(isTRUE(Investor_Goal==2)) {Investor_Goal=2
  } else if(isTRUE(Investor_Goal==3)) {Investor_Goal=3
  } else if(isTRUE(Investor_Goal==4)) {Investor_Goal=4
  } else if(isTRUE(Investor_Goal==5)) {Investor_Goal=5
  } else{Investor_Goal=5}

  if(isTRUE(Age_Investor>90)) {Age_Investor <- 90}
  if(isTRUE(Age_Investor<20)) {Age_Investor <- 20}

  if(isTRUE(Lambda >  10)) {Lambda <-  10}
  if(isTRUE(Lambda < -10)) {Lambda <- -10}

  if(isTRUE(Simulations >  1000000)) {Simulations <-  1000000}
  if(isTRUE(Simulations < 100)) {Simulations <- 100}

# Installment of packages needed to run the Betterment Modified Strategy
# to avoid prompt requests ,type = "source"


  if (!require(RCurl)) {
    install.packages("RCurl",type = "source")
    library(RCurl)
  } else {require(RCurl)}

  if (!require(jsonlite)) {
    install.packages("jsonlite",type = "source")
    library(jsonlite)
  } else {require(jsonlite)}

  if (!require(dplyr)) {
    install.packages("dplyr",type = "source")
    library(dplyr)
  } else {require(dplyr)}

  if (!require(plyr)) {
    install.packages("plyr",type = "source")
    library(plyr)
  } else {require(plyr)}

  if (!require(data.table)) {
    install.packages("data.table",type = "source")
    library(data.table)
  } else {require(data.table)}

  if (!require(purrr)) {
    install.packages("purrr",type = "source")
    library(purrr)
  } else {require(purrr)}

  if (!require(stringr)) {
    install.packages("stringr",type = "source")
    library(stringr)
  } else {require(stringr)}

  if (!require(stringi)) {
    install.packages("stringi",type = "source")
    library(stringi)
  } else {require(stringi)}

  if (!require(lubridate)) {
    install.packages("lubridate",type = "source")
    library(lubridate)
  } else {require(lubridate)}

  if (!require(httr)) {
    install.packages("httr",type = "source")
    library(httr)
  } else {require(httr)}

  if (!require(quantmod)) {
    install.packages("quantmod",type = "source")
    library(quantmod)
  } else {require(quantmod)}

  if (!require(corrplot)) {
    install.packages("corrplot",type = "source")
    library(corrplot)
  } else {require(corrplot)}

  if (!require(corpcor)) {
    install.packages("corpcor",type = "source")
    library(corpcor)
  } else {require(corpcor)}

  if (!require(BurStFin)) {
    install.packages("BurStFin",type = "source")
    library(BurStFin)
  } else {require(BurStFin)}

  if (!require(ggplot2)) {
    install.packages("ggplot2",type = "source")
    library(ggplot2)
  } else {require(ggplot2)}

  if (!require(reshape2)) {
    install.packages("reshape2",type = "source")
    library(reshape2)
  } else {require(reshape2)}

  if (!require(timeDate)) {
    install.packages("timeDate",type = "source")
    library(timeDate)
  } else {require(timeDate)}

  if (!require(RColorBrewer)) {
    install.packages("RColorBrewer",type = "source")
    library(RColorBrewer)
  } else {require(RColorBrewer)}

  if (!require(PortfolioAnalytics)) {
    install.packages("PortfolioAnalytics",type = "source")
    library(PortfolioAnalytics)
  } else {require(PortfolioAnalytics)}

  if (!require(ROI)) {
    install.packages("ROI",type = "source")
    library(ROI)
  } else {require(ROI)}

  if (!require(ROI.plugin.glpk)) {
    install.packages("ROI.plugin.glpk",type = "source")
    library(ROI.plugin.glpk)
  } else {require(ROI.plugin.glpk)}

  if (!require(ROI.plugin.quadprog)) {
    install.packages("ROI.plugin.quadprog",type = "source")
    library(ROI.plugin.quadprog)
  } else {require(ROI.plugin.quadprog)}

  if (!require(rugarch)) {
    install.packages("rugarch",type = "source")
    library(rugarch)
  } else {require(rugarch)}

  if (!require(tseries)) {
    install.packages("tseries",type = "source")
    library(tseries)
  } else {require(tseries)}

  if (!require(DataCombine)) {
    install.packages("DataCombine",type = "source")
    library(DataCombine)
  } else {require(DataCombine)}

  if (!require(forecast)) {
    install.packages("forecast",type = "source")
    library(forecast)
  } else {require(forecast)}


  print("Packages Installed Correctly")





#Then we can proceed to get the ETF data needed to implement the strategies


########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_A      ##################################
##################################                    ##################################
########################################################################################
########################################################################################

#Api Key to download data from eodhistoricaldata.com

api.token <- "5d80ef1d459f62.94373537"

#Getting the list of available ETFs on EODhistoricaldata.com

EtfSymbols <-read.csv("https://eodhistoricaldata.com/download/List_Of_Supported_ETFs.csv", header=TRUE)

# ETF Selection

etf_list <- as.data.frame(paste(EtfSymbols[,1], EtfSymbols[,2], sep = "."))

#Creation of the links to get all ETFs via API

temp_symbol <- as.data.frame(etf_list[,1])
URL <- cbind("https://eodhistoricaldata.com/api/fundamentals/", temp_symbol, "?api_token=", api.token, "&fmt=csv")

URL <- as.data.frame(paste(URL[,1],URL[,2],URL[,3],URL[,4],URL[,5], sep = ""))

#To look for the fundamental data of all ETFs in the list I will use a Vectorisation of the function below so as to increase the efficiency of the program and avoid inefficient For Loops

#Vectorisation of the function

system.time({
  Etfs <- Vectorize(function(i) tryCatch(fromJSON(getURL(URL[i,])), error=function(e) NA), SIMPLIFY = F) (1:nrow(etf_list))
})

Etfs <- Etfs[!is.na(Etfs)]




########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_B      ##################################
##################################                    ##################################
########################################################################################
########################################################################################

#General Data

Etfs_Data_Frame_General_Data = data.frame(matrix(data=NA, nrow = length(Etfs) , ncol = length(Etfs[[1]]$General)), stringsAsFactors = FALSE)


for(i in 1 : length(Etfs)) {
  for(j in 1 : length(Etfs[[1]]$General)) {
    tryCatch(Etfs_Data_Frame_General_Data[i,j] <- Etfs[[i]]$General[j], error=function(e) NA)
  }}

colnames(Etfs_Data_Frame_General_Data) <- names(Etfs[[1]]$General)

####################################################################

#Technicals

Etfs_Data_Frame_Technicals = data.frame(matrix(data=NA, nrow = length(Etfs) , ncol = length(Etfs[[1]]$Technicals)), stringsAsFactors = FALSE)


for(i in 1 : length(Etfs)) {
  for(j in 1 : length(Etfs[[1]]$Technicals)) {
    tryCatch(Etfs_Data_Frame_Technicals[i,j] <- Etfs[[i]]$Technicals[j], error=function(e) NA)
  }}

colnames(Etfs_Data_Frame_Technicals) <- names(Etfs[[1]]$Technicals)


####################################################################

# ETF Data Number 1

Etfs_Data_Frame_ETF_Data_1 = data.frame(matrix(data=NA, nrow = length(Etfs) , ncol = length(Etfs[[1]]$ETF_Data[1:14])), stringsAsFactors = FALSE)

system.time({
  for(i in 1 : length(Etfs)) {
    for(j in 1 : length(Etfs[[1]]$ETF_Data[1:14])) {
      tryCatch(Etfs_Data_Frame_ETF_Data_1[i,j] <- Etfs[[i]]$ETF_Data[j], error=function(e) NA)
    }}})

colnames(Etfs_Data_Frame_ETF_Data_1) <- names(Etfs[[1]]$ETF_Data[1:14])

# ETF Data Number 2 - World Regions

Etfs_Data_Frame_ETF_Data_2 = data.frame(matrix(data=NA, nrow = length(Etfs) , ncol = length(Etfs[[1]]$ETF_Data$World_Regions)), stringsAsFactors = FALSE)

system.time({
  for(i in 1 : length(Etfs)) {

    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,1] <- Etfs[[i]]$ETF_Data$World_Regions$`United States`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,2] <- Etfs[[i]]$ETF_Data$World_Regions$Canada[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,3] <- Etfs[[i]]$ETF_Data$World_Regions$`Latin America`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,4] <- Etfs[[i]]$ETF_Data$World_Regions$`United Kingdom`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,5] <- Etfs[[i]]$ETF_Data$World_Regions$Eurozone[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,6] <- Etfs[[i]]$ETF_Data$World_Regions$`Europe - except Euro`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,7] <- Etfs[[i]]$ETF_Data$World_Regions$`Europe - Emerging`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,8] <- Etfs[[i]]$ETF_Data$World_Regions$Africa[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,9] <- Etfs[[i]]$ETF_Data$World_Regions$`Middle East`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,10] <- Etfs[[i]]$ETF_Data$World_Regions$Japan[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,11] <- Etfs[[i]]$ETF_Data$World_Regions$Australasia[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,12] <- Etfs[[i]]$ETF_Data$World_Regions$`Asia - Developed`[1], error=function(e) NA)
    tryCatch(Etfs_Data_Frame_ETF_Data_2[i,13] <- Etfs[[i]]$ETF_Data$World_Regions$`Asia - Emerging`[1], error=function(e) NA)

  }})

colnames(Etfs_Data_Frame_ETF_Data_2) <- names(Etfs[[1]]$ETF_Data$World_Regions)

# ETF Data Number 3 - Performance

Etfs_Data_Frame_ETF_Data_3 = data.frame(matrix(data=NA, nrow = length(Etfs) , ncol = length(Etfs[[1]]$ETF_Data$Performance)), stringsAsFactors = FALSE)

system.time({
  for(i in 1 : length(Etfs)) {
    for(j in 1 : length(Etfs[[1]]$ETF_Data$Performance)) {
      tryCatch(Etfs_Data_Frame_ETF_Data_3[i,j] <- Etfs[[i]]$ETF_Data$Performance[j], error=function(e) NA)

    }}})

colnames(Etfs_Data_Frame_ETF_Data_3) <- names(Etfs[[1]]$ETF_Data$Performance)

# ETF Data Number 4 - Sustainability

Etfs_Data_Frame_ETF_Data_4 = data.frame(matrix(data=NA, nrow = length(Etfs) , ncol = length(Etfs[[1]]$ETF_Data$MorningStar$Ratio)), stringsAsFactors = FALSE)

system.time({
  for(i in 1 : length(Etfs)) {
    for(j in 1 : length(Etfs[[1]]$ETF_Data$MorningStar$Ratio)) {
      tryCatch(Etfs_Data_Frame_ETF_Data_4[i,j] <- Etfs[[i]]$ETF_Data$MorningStar$Ratio[j], error=function(e) NA)

    }}})

colnames(Etfs_Data_Frame_ETF_Data_4) <- names(Etfs[[1]]$ETF_Data$MorningStar)[1]

Etf_Complete_Matrix <- cbind(Etfs_Data_Frame_General_Data,Etfs_Data_Frame_Technicals,Etfs_Data_Frame_ETF_Data_1,Etfs_Data_Frame_ETF_Data_2[,1:12],Etfs_Data_Frame_ETF_Data_4, Etfs_Data_Frame_ETF_Data_3)

remove(Etfs_Data_Frame_ETF_Data_1,Etfs_Data_Frame_ETF_Data_2,Etfs_Data_Frame_ETF_Data_3,Etfs_Data_Frame_General_Data,Etfs_Data_Frame_Technicals,temp_symbol,URL,i,j,Etfs_Data_Frame_ETF_Data_4)



########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_C      ##################################
##################################                    ##################################
########################################################################################
########################################################################################

#To get Bulk Fundamental Data

Exchange_List <- as.data.frame(unique(EtfSymbols$Exchange))

US_Exchanges <- as.data.frame(c("NASDAQ", "NYSE", "BATS", "AMEX"))

names(Exchange_List) <- names(US_Exchanges)

Exchange_List <- rbind(Exchange_List,US_Exchanges)

Exchange_List<-Exchange_List[!(Exchange_List$`c("NASDAQ", "NYSE", "BATS", "AMEX")`=="US"),]

temp_exchange <- as.data.frame(Exchange_List)
URL_Bulk_Data <- cbind("https://eodhistoricaldata.com/api/eod-bulk-last-day/", temp_exchange, "?api_token=", api.token, "&fmt=json&filter=extended")

URL_Bulk_Data <- as.data.frame(paste(URL_Bulk_Data[,1],URL_Bulk_Data[,2],URL_Bulk_Data[,3],URL_Bulk_Data[,4],URL_Bulk_Data[,5], sep = ""))


for (i in 1 : nrow(URL_Bulk_Data)) {

  a <- tryCatch(fromJSON(getURL(URL_Bulk_Data[i,])), error=function(e) NA)

  if (i == 1) {Etfs_Bulk_Data = data.frame(matrix(data=NA, nrow = 1 , ncol = length(a)))}

  if (is_empty(a) == FALSE) {
    Etfs_Bulk_Data <- merge(Etfs_Bulk_Data, a, all = TRUE)
  }
  remove(a)

}

#Removing excess colummn

Etfs_Bulk_Data <- Filter(function(x)!all(is.na(x)), Etfs_Bulk_Data)

#Keeping only ETFs present in our initial database

Etfs_Bulk_Data <- Etfs_Bulk_Data[(Etfs_Bulk_Data$code %in% EtfSymbols$ETF.Code),]

########################################################################################

#Deleting securities that are not ETFs

Etf_Matrix <- Etf_Complete_Matrix

Etf_Matrix <- Etf_Matrix[(Etf_Matrix$Type=="ETF"),]

#Merging the two dataframes into one

Etf_Matrix <- merge(Etf_Matrix, Etfs_Bulk_Data, by.x = "Code", by.y = "code")

remove(temp_exchange, URL_Bulk_Data, Exchange_List, i, US_Exchanges)




########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_D      ##################################
##################################                    ##################################
########################################################################################
########################################################################################


# Checking the available categories

Categories <- as.data.frame(unique(Etf_Matrix$Category))

Number_ETFs_0 <- nrow(Etf_Matrix)

# 1st Screening: Remove ETFs in the following Asset Classes: Commodity, Currency, Trading, Metal, Industrial, Miscellaneous and Alternative

Etf_Matrix <- Etf_Matrix[!grepl("Commodity", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Commodities", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Alternative", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Multialternative", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Currency", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Trading", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Miscellaneous", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Metal", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Industrial", Etf_Matrix$Category),]


Number_ETFs_1 <- nrow(Etf_Matrix)

# 2nd Screening: Remove Inverse and Leveraged ETFs as done by Betterment

Etf_Matrix <- Etf_Matrix[!grepl("Inverse", Etf_Matrix$Category),]
Etf_Matrix <- Etf_Matrix[!grepl("Leverage", Etf_Matrix$Category),]

Number_ETFs_2 <- nrow(Etf_Matrix)

# 3rd Screening: Sector ETFs: we are trying to replicate the market based on the geography and not sectors

Etf_Matrix <- Etf_Matrix[!grepl("Sector", Etf_Matrix$Category),]

Number_ETFs_3 <- nrow(Etf_Matrix)

# 4th Screening: No Shorting

Etf_Matrix <- Etf_Matrix[!grepl("Short", Etf_Matrix$Category),]

Number_ETFs_4 <- nrow(Etf_Matrix)

# 5th Screening: Only ETFs for which Bulk Data is available

Etf_Matrix <- Etf_Matrix[(Etf_Matrix$Code %in% Etfs_Bulk_Data$code),]

Number_ETFs_5 <- nrow(Etf_Matrix)

# 6th Screening: Only ETFs for which the data is available and has been minimum for the past 5 years

Time <- as.POSIXlt(as.Date(Sys.Date()))

Time$year <- Time$year-5

Start <- as.Date(Time)
End <- as.Date(Sys.Date())

Current_Year <- year(now())
Beginning_Year <- paste(Current_Year,"-01-01", sep = "")

Etf_Matrix <- subset(Etf_Matrix, UpdatedAt >= Beginning_Year)
Etf_Matrix <- subset(Etf_Matrix, Inception_Date <= Start)

Number_ETFs_6 <- nrow(Etf_Matrix)

#Categorising as numeric the columns Net Expense Ratio and Avg.Vol200d so as to be able to sort the dataframes & to filter them

Etf_Matrix$NetExpenseRatio <- as.numeric(Etf_Matrix$NetExpenseRatio)

Etf_Matrix$avgvol_200d <- as.numeric(Etf_Matrix$avgvol_200d)

# 7th Screening: Only ETFs for which Net Expense Ratio is available and greater than 0

Etf_Matrix <- Etf_Matrix[(Etf_Matrix[,28]!=0),]

Number_ETFs_7 <- nrow(Etf_Matrix)

#Now we plot an horizontal bar chart to see how filtering the data changed the number of ETFs in our data

theme_set(theme_bw())
Bar_Chart <- data.frame(
  Number_Filter = c("Filter 0","Filter 1","Filter 2","Filter 3","Filter 4","Filter 5","Filter 6","Filter 7"),
  Number_ETFs = c(Number_ETFs_0, Number_ETFs_1,Number_ETFs_2,Number_ETFs_3, Number_ETFs_4,Number_ETFs_5,Number_ETFs_6,Number_ETFs_7)
)


png(filename="Bar_Chart.png")

Chart <- ggplot(data=Bar_Chart, aes(x=Number_Filter, y=Number_ETFs)) +
  geom_bar(stat="identity")
Chart + coord_flip()

dev.off()

Etf_Complete_Matrix$NetExpenseRatio <- as.numeric(Etf_Complete_Matrix$NetExpenseRatio)


# 8th Screening: Only ETFs for which Sustainability Ratio >= 3

if (isTRUE(Sustainable == "TRUE")) {

  Etf_Matrix <- subset(Etf_Matrix, Ratio >= 2)

  Number_ETFs_8 <- nrow(Etf_Matrix)

  #Now we plot an horizontal bar chart to see how filtering the data changed the number of ETFs in our data

  theme_set(theme_bw())
  Bar_Chart <- data.frame(
    Number_Filter = c("Filter 0","Filter 1","Filter 2","Filter 3","Filter 4","Filter 5","Filter 6","Filter 7","Filter 8"),
    Number_ETFs = c(Number_ETFs_0, Number_ETFs_1,Number_ETFs_2,Number_ETFs_3, Number_ETFs_4,Number_ETFs_5,Number_ETFs_6,Number_ETFs_7,Number_ETFs_8)
  )


  png(filename="Bar_Chart.png")

  Chart <- ggplot(data=Bar_Chart, aes(x=Number_Filter, y=Number_ETFs)) +
    geom_bar(stat="identity")
  Chart + coord_flip()

  dev.off()

  Etf_Complete_Matrix$NetExpenseRatio <- as.numeric(Etf_Complete_Matrix$NetExpenseRatio)


}



########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_E      ##################################
##################################                    ##################################
########################################################################################
########################################################################################

# After this first level of Screening I will go on to divide the ETFs in 11 sub categories, 6 Equity categories and 5 Fixed Income categories


#Let's start with the Equity Categories: US Total, US Large, US Mid, US Small, International, Emerging markets

Etf_Matrix_US_Total <- Etf_Matrix[grepl("Large Blend", Etf_Matrix$Category),]

Etf_Matrix_US_Total <- Etf_Matrix_US_Total[!grepl("Foreign", Etf_Matrix_US_Total$Category),]

Etf_Matrix_US_Total <- Etf_Matrix_US_Total[!grepl("Bond", Etf_Matrix_US_Total$Category),]

Etf_Matrix_US_Total <- subset(Etf_Matrix_US_Total, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_US_Large <- Etf_Matrix[grepl("US Large|Large Value", Etf_Matrix$Category),]

Etf_Matrix_US_Large <- Etf_Matrix_US_Large[!grepl("Bond|Euro|Emerging|Foreign|Global|Asia|Japan|Israel|UK|France", Etf_Matrix_US_Large$Category),]

Etf_Matrix_US_Large <- subset(Etf_Matrix_US_Large, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_US_Mid <- Etf_Matrix[grepl("US Mid|Mid-Cap", Etf_Matrix$Category),]

Etf_Matrix_US_Mid <- Etf_Matrix_US_Mid[!grepl("Bond|Euro|Emerging|Foreign|Global|Asia|Japan|Israel|UK|France", Etf_Matrix_US_Mid$Category),]

Etf_Matrix_US_Mid <- subset(Etf_Matrix_US_Mid, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_US_Small <- Etf_Matrix[grepl("US Small|Small", Etf_Matrix$Category),]

Etf_Matrix_US_Small <- Etf_Matrix_US_Small[!grepl("Bond|Euro|Emerging|Foreign|Global|Asia|Japan|Israel|UK|France", Etf_Matrix_US_Small$Category),]

Etf_Matrix_US_Small <- subset(Etf_Matrix_US_Small, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_International <- Etf_Matrix[grepl("Euro|Europe|International|Foreign", Etf_Matrix$Category),]

Etf_Matrix_International <- Etf_Matrix_International[!grepl("Bond|Emerging|Global|Asia|Japan|Israel|UK|France", Etf_Matrix_International$Category),]

Etf_Matrix_International <- subset(Etf_Matrix_International, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_Emerging <- Etf_Matrix[grepl("Emerging", Etf_Matrix$Category),]

Etf_Matrix_Emerging <- Etf_Matrix_Emerging[!grepl("Europe|Bond", Etf_Matrix_Emerging$Category),]

Etf_Matrix_Emerging <- subset(Etf_Matrix_Emerging, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

#Let's continue with the Bond categories: ST Treasuries, Inflation Protected, US High Quality, Intl.Developed and Emerging Markets

Etf_Matrix_Bond <- Etf_Matrix[grepl("Bond", Etf_Matrix$Category),]

Etf_Matrix_Bond_Treasuries <- Etf_Matrix_Bond[grepl("Ultrashort", Etf_Matrix_Bond$Category),]

Etf_Matrix_Bond_Treasuries <- subset(Etf_Matrix_Bond_Treasuries, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_Bond_TIPS <- Etf_Matrix_Bond[grepl("Inflation", Etf_Matrix_Bond$Category),]

Etf_Matrix_Bond_TIPS <- subset(Etf_Matrix_Bond_TIPS, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_Bond_High_Quality <- Etf_Matrix_Bond[grepl("Intermediate Core", Etf_Matrix_Bond$Category),]

Etf_Matrix_Bond_High_Quality <- subset(Etf_Matrix_Bond_High_Quality, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_Bond_International <- Etf_Matrix_Bond[grepl("International|World", Etf_Matrix_Bond$Category),]

Etf_Matrix_Bond_International <- Etf_Matrix_Bond_International[!grepl("Emerging|Inflation|Corporate!Hedged", Etf_Matrix_Bond_International$Category),]

Etf_Matrix_Bond_International <- subset(Etf_Matrix_Bond_International, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))

Etf_Matrix_Bond_Emerging <- Etf_Matrix_Bond[grepl("Emerging", Etf_Matrix_Bond$Category),]

Etf_Matrix_Bond_Emerging <- Etf_Matrix_Bond_Emerging[!grepl("Corporate", Etf_Matrix_Bond_Emerging$Category),]

Etf_Matrix_Bond_Emerging <- subset(Etf_Matrix_Bond_Emerging, avgvol_200d > quantile(avgvol_200d, prob = 0.8, na.rm = TRUE))


########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_F      ##################################
##################################                    ##################################
########################################################################################
########################################################################################

# Now we can move on to choosing the ETF for each category

### Equity

## US Total

Etf_Matrix_US_Total <- Etf_Matrix_US_Total[order(Etf_Matrix_US_Total[,"NetExpenseRatio"], -Etf_Matrix_US_Total[, "avgvol_200d"]),]

Equity_US_Total <- Etf_Matrix_US_Total[1,]

## US Large

Etf_Matrix_US_Large <- Etf_Matrix_US_Large[order(Etf_Matrix_US_Large[,"NetExpenseRatio"], -Etf_Matrix_US_Large[, "avgvol_200d"]),]

Equity_US_Large <- Etf_Matrix_US_Large[1,]

## US Mid

Etf_Matrix_US_Mid <- Etf_Matrix_US_Mid[order(Etf_Matrix_US_Mid[,"NetExpenseRatio"], -Etf_Matrix_US_Mid[,"avgvol_200d" ]),]

Equity_US_Mid <- Etf_Matrix_US_Mid[1,]

## US Small

Etf_Matrix_US_Small <- Etf_Matrix_US_Small[order(Etf_Matrix_US_Small[,"NetExpenseRatio"], -Etf_Matrix_US_Small[, "avgvol_200d"]),]

Equity_US_Small <- Etf_Matrix_US_Small[1,]

## International

Etf_Matrix_International <- Etf_Matrix_International[order(Etf_Matrix_International[,"NetExpenseRatio"], -Etf_Matrix_International[, "avgvol_200d"]),]

Equity_International <- Etf_Matrix_International[1,]

## Emerging

Etf_Matrix_Emerging <- Etf_Matrix_Emerging[order(Etf_Matrix_Emerging[,"NetExpenseRatio"], -Etf_Matrix_Emerging[, "avgvol_200d"]),]

Equity_Emerging <- Etf_Matrix_Emerging[1,]

### Bond

## Treasuries

Etf_Matrix_Bond_Treasuries <- Etf_Matrix_Bond_Treasuries[order(Etf_Matrix_Bond_Treasuries[,"NetExpenseRatio"], -Etf_Matrix_Bond_Treasuries[, "avgvol_200d"]),]

Bond_Treasuries <- Etf_Matrix_Bond_Treasuries[1,]

## TIPS

Etf_Matrix_Bond_TIPS <- Etf_Matrix_Bond_TIPS[order(Etf_Matrix_Bond_TIPS[,"NetExpenseRatio"], -Etf_Matrix_Bond_TIPS[, "avgvol_200d"]),]

Bond_TIPS <- Etf_Matrix_Bond_TIPS[1,]

## High Quality

Etf_Matrix_Bond_High_Quality <- Etf_Matrix_Bond_High_Quality[order(Etf_Matrix_Bond_High_Quality[,"NetExpenseRatio"], -Etf_Matrix_Bond_High_Quality[, "avgvol_200d"]),]

Bond_High_Quality <- Etf_Matrix_Bond_High_Quality[1,]

## International

Etf_Matrix_Bond_International <- Etf_Matrix_Bond_International[order(Etf_Matrix_Bond_International[,"NetExpenseRatio"], -Etf_Matrix_Bond_International[, "avgvol_200d"]),]

Bond_International <- Etf_Matrix_Bond_International[1,]

## Emerging

Etf_Matrix_Bond_Emerging <- Etf_Matrix_Bond_Emerging[order(Etf_Matrix_Bond_Emerging[,"NetExpenseRatio"], -Etf_Matrix_Bond_Emerging[, "avgvol_200d"]),]

Bond_Emerging <- Etf_Matrix_Bond_Emerging[1,]

#Removing variables not needed

remove(a,Categories,Categories2,Etf_Avg_Vol,Etf_Net_Expense_Ratio,US_Total, US_Mid, Etf_Matrix_Bond_Emerging, Etf_Matrix_Bond_High_Quality, Etf_Matrix_Bond_International, Etf_Matrix_Bond_TIPS, Etf_Matrix_Bond_Treasuries, Etf_Matrix_US_Total, Etf_Matrix_US_Large, Etf_Matrix_US_Mid, Etf_Matrix_US_Small, Etf_Matrix_Emerging, Etf_Matrix_International, Beginning_Year, Current_Year, End, i, Start, Time, Value, Etf_Matrix_Bond)



########################################################################################
########################################################################################
##################################                    ##################################
##################################      PART 1_G      ##################################
##################################                    ##################################
########################################################################################
########################################################################################

#Creating overall dataframe for all ETFs

Selected_ETFs <- data.frame(matrix(nrow=11, ncol=ncol(Bond_Emerging)))

Selected_ETFs[1,] <- Equity_US_Total
Selected_ETFs[2,] <- Equity_US_Large
Selected_ETFs[3,] <- Equity_US_Mid
Selected_ETFs[4,] <- Equity_US_Small
Selected_ETFs[5,] <- Equity_Emerging
Selected_ETFs[6,] <- Equity_International
Selected_ETFs[7,] <- Bond_Treasuries
Selected_ETFs[8,] <- Bond_TIPS
Selected_ETFs[9,] <- Bond_International
Selected_ETFs[10,] <- Bond_High_Quality
Selected_ETFs[11,] <- Bond_Emerging

colnames(Selected_ETFs) <- colnames(Bond_Emerging)

Categories <-as.data.frame(c("Equity US Total", "Equity US Large", "Equity US Mid", "Equity US Small", "Equity Emerging", "Equity International", "Bond Treasuries", "Bond TIPS", "Bond International", "Bond High Quality", "Bond Emerging"))

colnames(Categories) <- "ETF Category"

Selected_ETFs <- cbind(Categories, Selected_ETFs)

remove(Bond_Emerging, Bond_High_Quality, Bond_International, Bond_TIPS, Bond_Treasuries, Equity_US_Mid, Equity_US_Small, Equity_US_Total, Equity_Emerging, Equity_International, Equity_US_Large, Categories, etf_list,EtfSymbols)

#Colculating average Net Expense Ratio for complete dataset and for Selected ETFs

Avg_Dataset <- mean(Etf_Complete_Matrix$NetExpenseRatio, na.rm = TRUE)
Avg_Selected_ETFs <- mean(Selected_ETFs$NetExpenseRatio, na.rm = TRUE)


print("Data downloaded and ETF selected")


#####################################################################
#####################################################################
########################                    #########################
########################      PART 2_A      #########################
########################                    #########################
#####################################################################
#####################################################################

#Calculating the correlation among the different ETFs selected in order to optimize the portfolio and create a correlation matrix

#To calculate the matrix, the historical data from the past 5 years from the ETFs selected will be used.

# Get quantmod and set beginning and end dates for time period under observation

#As a first step to download the data through the API we set the begin and end dates

Time <- as.POSIXlt(as.Date(Sys.Date()))
Time$year <- Time$year-5


Start <- as.Date(Time)
End <- as.Date(Sys.Date())

#Then we convert the start and end date into UNIX to be able to use them inside the intraday API

Start_Unix <- as.numeric(as.POSIXct(Start))
End_Unix <- as.numeric(as.POSIXct(End))

#Now we download the EOD data for each day in the selected period (5 years)

for (i in 1: nrow(Selected_ETFs)) {

  temp_symbol <- Selected_ETFs[i,2]
  URL <- paste("https://eodhistoricaldata.com/api/eod/", temp_symbol, "?from=" , Start, "&to", End, "&api_token=", api.token, "&period=d&fmt=json", sep="")


  Dataframe_Name <- paste(Selected_ETFs[i,1])
  #assign(Dataframe_Name, fromJSON(getURL(URL)))

  a <- tryCatch(fromJSON(getURL(URL)), error=function(e) NA)
  assign(Dataframe_Name, a )

}

Minimum_Length <- min(nrow(`Equity US Total`), nrow(`Equity US Large`), nrow(`Equity US Mid`), nrow(`Equity US Small`), nrow(`Equity Emerging`), nrow(`Equity International`), nrow(`Bond Treasuries`), nrow(`Bond TIPS`), nrow(`Bond International`), nrow(`Bond High Quality`), nrow(`Bond Emerging`))

`Equity US Large` <- `Equity US Large`[1:Minimum_Length,]
`Equity US Total` <- `Equity US Total`[1:Minimum_Length,]
`Equity US Mid` <- `Equity US Mid`[1:Minimum_Length,]
`Equity US Small` <- `Equity US Small`[1:Minimum_Length,]
`Equity Emerging` <- `Equity Emerging`[1:Minimum_Length,]
`Equity International` <- `Equity International`[1:Minimum_Length,]
`Bond TIPS` <- `Bond TIPS`[1:Minimum_Length,]
`Bond Treasuries` <- `Bond Treasuries`[1:Minimum_Length,]
`Bond Emerging` <- `Bond Emerging`[1:Minimum_Length,]
`Bond High Quality` <- `Bond High Quality`[1:Minimum_Length,]
`Bond International` <- `Bond International`[1:Minimum_Length,]


ETF_EOD_Data <- data.frame(matrix(nrow=nrow(`Bond Emerging`), ncol=nrow(Selected_ETFs)))

ETF_EOD_Data[,1] <- `Equity US Total`$close
ETF_EOD_Data[,2] <- `Equity US Large`$close
ETF_EOD_Data[,3] <- `Equity US Mid`$close
ETF_EOD_Data[,4] <- `Equity US Small`$close
ETF_EOD_Data[,5] <- `Equity Emerging`$close
ETF_EOD_Data[,6] <- `Equity International`$close
ETF_EOD_Data[,7] <- `Bond Treasuries`$close
ETF_EOD_Data[,8] <- `Bond TIPS`$close
ETF_EOD_Data[,9] <- `Bond International`$close
ETF_EOD_Data[,10] <- `Bond High Quality`$close
ETF_EOD_Data[,11] <- `Bond Emerging`$close

colnames(ETF_EOD_Data) <- Selected_ETFs$`ETF Category`

Correlation_Matrix <- data.frame(matrix(nrow=nrow(Selected_ETFs), ncol=nrow(Selected_ETFs)))

colnames(Correlation_Matrix) <- Selected_ETFs$`ETF Category`
rownames(Correlation_Matrix) <- Selected_ETFs$`ETF Category`

for (i in 1: nrow(Selected_ETFs)) {
  for(j in 1: nrow(Selected_ETFs)) {

    Correlation_Matrix[i,j] <- cor(ETF_EOD_Data[,i], ETF_EOD_Data[,j])

  }}

remove(Dataframe_Name,End_Unix, Start_Unix,i,Time,URL,temp_symbol, Minimum_Length,j)

#Now we plot and save the correlation matrix

png(filename="CorrPlot.png")
print(corrplot.mixed(as.matrix(Correlation_Matrix), upper = "ellipse", lower.col = "black", tl.pos = "lt"))
dev.off()
print(corrplot.mixed(as.matrix(Correlation_Matrix), upper = "ellipse", lower.col = "black", tl.pos = "lt"))

#Now we proceed to do analyse our time series in order to understand how to proceed in forecasting the prices




#####################################################################
#####################################################################
########################                    #########################
########################      PART 2_B      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now we move on to the portfolio optimization part: to compute the expected returns on the Betterment portfolio, we need the Covariance matrix estimated through the Ledoit and Wolf (2003) method

#Given that the automation of this program leads to the possibility of having different ETFs at each trial run, the package "corpcor" gives the possibility to minimise MSE while estimatting the optimal shrinkage intensity lambda

#This method is particularly helpful for cases such as this one when n (#ETFs) is small and p (#datapoints for each n) is large

Returns_Matrix <- data.frame(matrix(nrow=nrow(ETF_EOD_Data)-1, ncol=ncol(ETF_EOD_Data)))

for (i in 1: nrow(Selected_ETFs)) {

  Returns_Matrix[,i] <- diff(log(ETF_EOD_Data[,i]),lag=1)

}



#Now we download the updated data for the risk-free rate:

getSymbols("DGS10",src="FRED")

Risk_Free_Rate <- DGS10[nrow(DGS10),1]

remove(DGS10)

Daily_Risk_Free_Rate <- (1+Risk_Free_Rate/100)^(1/252) - 1

Daily_Risk_Free_Rate <- as.numeric(Daily_Risk_Free_Rate)

Excess_Returns_Matrix <- Returns_Matrix - Daily_Risk_Free_Rate

#Now we can calculate the shrank Cov Matrix

Cov_Matrix <- cov.shrink(Returns_Matrix)

#Now to calculate the Global Market Portfolio Weights, given the unavailability of these weights on the Betterment Website and the lack on data on a granular level for global market capitalisation for each asset class, we will proceed by calculating the weights based on the market cap of the Equity and Bond market, then this two markets will be further divided to reach the global portfolio weights. A moro thorough explanation of the calculations is available on the Excel "Global_Portfolio_Weights.xlsx"

Weights_Global_Portfolio <- data.frame(matrix(nrow=nrow(Selected_ETFs), ncol=1))

rownames(Weights_Global_Portfolio) <- colnames(ETF_EOD_Data)

colnames(Weights_Global_Portfolio) <- "Weights"

Weights_Global_Portfolio[1,1] <- 0.138203
Weights_Global_Portfolio[2,1] <- 0.116209
Weights_Global_Portfolio[3,1] <- 0.008302
Weights_Global_Portfolio[4,1] <- 0.003176
Weights_Global_Portfolio[5,1] <- 0.041382
Weights_Global_Portfolio[6,1] <- 0.173890
Weights_Global_Portfolio[7,1] <- 0.132415
Weights_Global_Portfolio[8,1] <- 0.010367
Weights_Global_Portfolio[9,1] <- 0.276281
Weights_Global_Portfolio[10,1] <- 0.083172
Weights_Global_Portfolio[11,1] <- 0.016603

#The final available weights seem reasonable and in line with the market

#Now we will procees to calculate the returns as done by Betterment by a reverse-engineering method: μ = λ Σ ωmarket
#We have the shrank covariance matrix calculated according to Ledoit and Wolf (2003) and we have reasonably estimated the global portfolio weights for the different asset classes.
#Now the only thing left to estimate is λ, the risk aversion parameter

#As defined in Pratt (1964), the λ is between 3 and 4

#Therefore we will use 3.5 as an average estimate of λ

Lambda <- Lambda

# By using CAPM, the expected return is essentially determined to be proportional to the asset’s contribution to the overall portfolio risk. (cit.Betterment)

Forward_Looking_Returns <- Lambda * Cov_Matrix * Weights_Global_Portfolio
colnames(Forward_Looking_Returns) <- "Forward_Looking_Returns"


#Black-Litterman starts with our global market portfolio as the asset allocation that an investor should take in the absence of views on the underlying assets. Then, using the Idzorek implementation of Black-Litterman, the Betterment Portfolio Strategy is tilted based on the level of confidence we have for our views on size and value. These views are computed from historical data analysis, and our confidence level is a free parameter of the implementation.

#The new method asserts that the magnitude of the tilts should be controlled by the user-specified confidence level based on an intuitive 0% to 100% confidence level.

#However this part of the Betterment strategy is inherently subjective and given the purpose of this paper to produre a Robo advisor completely autonomous following Betterment's Strategy, the "tilting" procedure is avoided, because inputing them would mean having a part of the program that needs constant research and changes which would undermine the main purpose of this thesis.





#Removing excess variables

remove(i, URL)





#####################################################################
#####################################################################
########################                    #########################
########################      PART 2_C      #########################
########################                    #########################
#####################################################################
#####################################################################


#Now we proceed to estimating the returns based on the views on the market. To do this we will implement the Black Litterman model. However, to keep the objectivity needed to run this code autonomously we will proceed by estimating the views on the assets through an ARMA-eGarch model

#We can then move on to forecast our views

#We will use the eGarch model for the volatility forecast and for the mean model we first need to see whether the time series are stationary, in which case we use the ARMA model or not.

ADF_PValue <- data.frame(matrix(nrow=nrow(Selected_ETFs), ncol=2))

for(i in 1:nrow(Selected_ETFs)) {

  acf(ETF_EOD_Data[,i], lag.max = 1000)

  acf(Returns_Matrix[,i], lag.max = 1000)

  temp <- adf.test(ETF_EOD_Data[,i])

  ADF_PValue[i,1] <- temp$p.value[1]

}

# Then, since the time series are all non-stationary we difference them once

Diff_Time_Series <- data.frame(matrix(nrow=nrow(ETF_EOD_Data)-1, ncol=ncol(ETF_EOD_Data)))

for(i in 1:nrow(Selected_ETFs)) {

  Diff_Time_Series[,i] <- diff(ETF_EOD_Data[,i], differences=1)

  temp <- adf.test(Diff_Time_Series[,i])

  ADF_PValue[i,2] <- temp$p.value[1]

}

#Now that we reached stationarity in all the times series (p-value smaller than 0.01 in each of them) we know that we will use an ARIMA model.

#To do this we first estimate the best p,q for the model based on information criteria

LogL <- matrix(0,nrow=3,ncol=3)
Params <- matrix(0,nrow=3,ncol=3)
Aic <- matrix(0,nrow=3,ncol=3)
Control = list(RHO = 1,DELTA = 1e-8,MAJIT = 100,MINIT = 650,TOL = 1e-6)

PQ_Matrix = matrix(0,nrow=nrow(Selected_ETFs),ncol=2)
suppressWarnings(
  for(i in 1 : nrow(Selected_ETFs)) {
    for (p in 1:3) {
      for (q in 1:3) {
        spec <- ugarchspec(mean.model=list(armaOrder=c(p,1,q)),variance.model=list(model = "eGARCH",garchOrder=c(1,1)))
        fit <- ugarchfit(spec=spec,data= Returns_Matrix[,i],solver = "hybrid", solver.control = Control)
        LogL[p,q] <- likelihood(fit)
        Params[p,q] <- length(coef(fit))
        Aic[p,q] <- infocriteria(fit)[1]

        #Now we choose and input the best p,q for each of the selected ETFs in the PQ_Matrix
        Indices = which(Aic == min(Aic), arr.ind=TRUE)
        PQ_Matrix[i,1] = Indices[1,1]
        PQ_Matrix[i,2] = Indices[1,2]
      }
    }
  }
)

Mean_Estimate = matrix(0,nrow=nrow(Selected_ETFs),ncol=1)
Vola_Estimate = matrix(0,nrow=nrow(Selected_ETFs),ncol=1)

for(i in 1:nrow(Selected_ETFs)) {

  spec <- ugarchspec(mean.model=list(armaOrder=c(PQ_Matrix[i,1],1,PQ_Matrix[i,2])),variance.model=list(model = "eGARCH",garchOrder=c(1,1)))

  fit <- ugarchfit(spec=spec,data= Returns_Matrix[,i],solver = "hybrid", solver.control = Control)

  #Now that we have the mean forecast for the daily return we can convert it to yearly return and then compute our views based on that

  eGarch_Forecast <- ugarchforecast(fit,n.ahead = 252)
  Mean_Estimate[i] <- mean(fitted(eGarch_Forecast))
  Vola_Estimate[i] <- mean(sigma(eGarch_Forecast))
}

Mean_Estimate <- as.data.frame(Mean_Estimate) - Daily_Risk_Free_Rate

rownames(Mean_Estimate) = colnames(ETF_EOD_Data)

#Now we move to formatting the views in such a way that they can be used as input in the Black-Litterman model.

#Given that the views that we express are absolute, we are going to input 1 in each row (view) in the column corresponding to the respective asset. Therefore, the P matrix will be equal to the identity matrix

P_Matrix = diag(11)

colnames(P_Matrix) <- colnames(ETF_EOD_Data)

#Now we move to calculating the variances for each of the individual portfolios (views). This will be done through pk Σpk' where pk is the 1xN vector of the kth view and Σ is the covariance matrix of excess returns

Individual_Variances <- matrix(0,nrow=nrow(Selected_ETFs),ncol=1)

for(i in 1: nrow(Selected_ETFs)) {

  Individual_Variances[i] = t(P_Matrix[i,])%*%Cov_Matrix%*%P_Matrix[i,]


}


#Now we move to calculating the scalar tau, a parameter that is inversely proportional to the level of confidence expressed in the views

#He and Litterman (1999) calibrate the confidence of a view so that the ratio of ω τ is equal to the variance of the view portfolio ( pk Σpk' ). Assuming τ = 0.025 and using the individual variances of the view portfolios ( pk Σpk' )

#When the covariance matrix of the error term ( Ω ) is calculated using this method, the actual value of the scalar (τ ) becomes irrelevant because only the ratio ω /τ enters the model. For example, changing the assumed value of the scalar (τ ) from 0.025 to 15 dramatically changes the value of the diagonal elements of Ω , but the new Combined Return Vector ( E[R]) is unaffected.



Tau = 0.03

Cov_Matrix_Error_Term = matrix(0,nrow=nrow(Selected_ETFs),ncol=nrow(Selected_ETFs))

for(i in 1:nrow(Selected_ETFs)) {


  Cov_Matrix_Error_Term[i,i] = Tau * Individual_Variances[i]

}

#He and Litterman (1999) and Litterman (2003) suggest that, in the presence of constraints, the investor input the New Combined Return Vector ( E[R]) into a mean-variance optimizer.


# Bevan and Winkelmann (1998) offer guidance in setting the weight given to the View Vector (Q). After deriving an initial Combined Return Vector (E[R]) and the subsequent optimum portfolio weights, they calculate the anticipated Information Ratio of the new portfolio. They recommend a maximum anticipated Information Ratio of 2.0. If the Information Ratio is above 2.0, decrease the weight given to the views (decrease the value of the scalar and leave the diagonal elements of Ω unchanged).

# We now compute the combined return vector as:E[R]=[(τΣ)^-1 +P'Ω P]^-1[(τΣ)^-1 Π+P'Ω Q]

Combined_Return_Vector =  inv(inv(Tau*Cov_Matrix) + P_Matrix * inv(Cov_Matrix_Error_Term) * P_Matrix) * (inv(Tau*Cov_Matrix)*Forward_Looking_Returns + P_Matrix * inv(Cov_Matrix_Error_Term) * Mean_Estimate)

print("Vector of returns computed")


#####################################################################
#####################################################################
########################                    #########################
########################      PART 3_A      #########################
########################                    #########################
#####################################################################
#####################################################################

#We continue doing a MC simulation for 5 years with 1000 simulations of stock prices:

# St+1 = St * exp(μΔt + σε√Δt)

Years <- Years # We assume a forecast period of 5 years
Trading_Days_Year <- 252
Time = round(Years * Trading_Days_Year, digits = 0)
Delta <- 1 / Trading_Days_Year
Simulations <- Simulations #We simulate 1000 times the stock price movement

#Create Date Column with trading days to add to each MC Simulation

Starting_Date <- End
End_Date <- Starting_Date + (365*40) #Years
holidays = holidayNYSE()
Seq_Days = as.timeDate(seq(from = Starting_Date, to = End_Date, by = "day"))
Seq_Days <- Seq_Days[isBizday(Seq_Days, holidays = holidays, wday = 1:5)]
Seq_Days <- Seq_Days[1:(Time+1),]
Seq_Days <- as.data.frame(Seq_Days)

n <- (nrow(Selected_ETFs)+1) #number of columns to insert data into array

#Creating the Matrix for each simulation

Stock_Prices <- data.frame(matrix(nrow=Time + 1, ncol = Simulations ))
Stock_Prices <- cbind(Seq_Days[,1], Stock_Prices)
colnames(Stock_Prices)[1] = "Date"

#Creating a 3 dimensional array to keep the simulations for future rebalancing in Part 5

Array_Stock_Prices_MC <-array(0,dim=c(nrow(Stock_Prices),nrow(Selected_ETFs)+1,ncol(Stock_Prices)-1))

#Create dataframes for Average return and forward return

Average_Daily_Return <- data.frame(matrix(nrow=nrow(Selected_ETFs), ncol = 1 ))
Forward_Return <- data.frame(matrix(nrow=nrow(Selected_ETFs), ncol = 1 ))
BL_Return <- data.frame(matrix(nrow=nrow(Selected_ETFs), ncol = 1 ))

set.seed(123) # to make the program reproducible

Z <- rnorm(Time*Simulations*nrow(Selected_ETFs), mean = 0, sd = 1)

system.time({
  for (i in 1: nrow(Selected_ETFs)) {
    for (k in 1 : Simulations) {

      Stock_Prices[1,2:ncol(Stock_Prices)] <- ETF_EOD_Data[nrow(ETF_EOD_Data),i]

      Average_Daily_Return[i,1] <- (1+mean(Returns_Matrix[,i], na.rm = TRUE))^Trading_Days_Year - 1

      Forward_Return[i,1] <- (1+Forward_Looking_Returns[i,1])^Trading_Days_Year - 1

      BL_Return[i,1] <- (1+Combined_Return_Vector[i,1])^Trading_Days_Year - 1

      Variance <- Cov_Matrix[i,i]*sqrt(Trading_Days_Year)

      Array_Stock_Prices_MC[,1,k] <- Seq_Days[,1]

      Array_Stock_Prices_MC[1,i+1,k] <- ETF_EOD_Data[nrow(ETF_EOD_Data),i]

      for (j in 1: Time) {

        Stock_Prices[j+1,k+1] <- Stock_Prices[j,k+1] * exp((BL_Return[i,1]-0.5*sqrt(Variance))*Delta+sqrt(Variance)*Z[j+Simulations*(k-1)+Simulations*Time*(i-1)]*sqrt(Delta))

        Array_Stock_Prices_MC[j+1,i+1,k] <- Stock_Prices[j+1,k+1]

      }}
    require(ggplot2)
    require(reshape2)

    Stock_Prices_Melted <- melt(Stock_Prices, id.var='Date')

    Plot_Name <- paste("MC_", colnames(ETF_EOD_Data[i]), ".png", sep = "")

    png(filename=Plot_Name)

    print(ggplot(Stock_Prices_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Stock Price') + theme_minimal() + theme(legend.position = "none") + scale_color_brewer(palette = "RdBu"))

    dev.off()

    Dataframe_Name <- paste("MC_", colnames(ETF_EOD_Data[i]), sep = "")
    assign(Dataframe_Name, Stock_Prices)

  }

})

#Now we create a Price evolution from the average of the prices in the MC method

Average_MC <- data.frame(matrix(nrow=length(Array_Stock_Prices_MC[,1,1])), ncol=ncol(ETF_EOD_Data))

for(j in 1:length(Array_Stock_Prices_MC[,1,1])) {
  for(i in 1:Simulations) {
    for(k in 1:nrow(Selected_ETFs)) {

      Average_MC[j,k] <- median(Array_Stock_Prices_MC[j,k+1,i])

    }}}


#Let's plot the median value for each of the simulations

require(ggplot2)
require(reshape2)

Average_MC <- cbind(`MC_Bond Emerging`[,1] ,Average_MC)

colnames(Average_MC)[1] = "Date"

colnames(Average_MC)[2:12] = colnames(ETF_EOD_Data)

Average_MC_Melted <- melt(Average_MC, id.var='Date')

png(filename="Average_MC.png")

print(ggplot(Average_MC_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Stock Price') + theme_minimal())

dev.off()

print(ggplot(Average_MC_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Price') + theme_minimal())




#####################################################################
#####################################################################
########################                    #########################
########################      PART 3_B      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now we create the portfolio values overtime for each simulation and then we put them in increasing order for w.r.t. the end value. The weights used are the weights of the market portfolio

Portfolio_Value_Overtime_MC <- data.frame(matrix(nrow=length(Array_Stock_Prices_MC[,1,1]), ncol=Simulations))

for(i in 1:Simulations) {
  for(j in 1:length(Array_Stock_Prices_MC[,1,1])) {

    Portfolio_Value_Overtime_MC[j,i] = sum(Array_Stock_Prices_MC[j,2:12,i]*Weights_Global_Portfolio*Initial_Investment/Array_Stock_Prices_MC[1,2:12,i])


  }}

Portfolio_Value_Overtime_MC <- Portfolio_Value_Overtime_MC[,order(Portfolio_Value_Overtime_MC[nrow(Portfolio_Value_Overtime_MC),])]

Portfolio_Value_Overtime_MC_Quantile <- Portfolio_Value_Overtime_MC[,c(1,ceiling(0.01*Simulations),ceiling(0.05*Simulations),ceiling(0.10*Simulations),ceiling(0.25*Simulations),ceiling(0.50*Simulations),ceiling(0.75*Simulations),ceiling(0.90*Simulations),ceiling(0.95*Simulations),ceiling(0.99*Simulations),Simulations)]

Portfolio_Value_Overtime_MC_Quantile <- Portfolio_Value_Overtime_MC_Quantile[,order(Portfolio_Value_Overtime_MC_Quantile[nrow(Portfolio_Value_Overtime_MC_Quantile),])]

Portfolio_Value_Overtime_MC_Quantile <- cbind(Seq_Days[,1],Portfolio_Value_Overtime_MC_Quantile)

#Let's plot these portfolio values:

require(ggplot2)
require(reshape2)

colnames(Portfolio_Value_Overtime_MC_Quantile)[1] = "Date"
colnames(Portfolio_Value_Overtime_MC_Quantile)[2:12] <- c("Min", "1%", "5%", "10%", "25%", "50%", "75%", "90%", "95%", "99%", "Max")

Portfolio_Value_Overtime_MC_Quantile_Melted <- melt(Portfolio_Value_Overtime_MC_Quantile, id.var='Date')

png(filename="Portfolio_Value_Overtime_MC.png")

print(ggplot(Portfolio_Value_Overtime_MC_Quantile_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Portfolio Overtime MC Simulations') + theme_minimal())

dev.off()

print(ggplot(Portfolio_Value_Overtime_MC_Quantile_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Portfolio Overtime MC Simulations') + theme_minimal())

#Now we produce some statistics on the Portfolio return:

Yearly_Portfolio_Return = as.numeric((Portfolio_Value_Overtime_MC[nrow(Portfolio_Value_Overtime_MC),]/Portfolio_Value_Overtime_MC[1,])^(1/Years) - 1)

plot((Yearly_Portfolio_Return))



Portfolio_Returns_Moments <- data.frame(matrix(nrow=14, ncol = 3))

i = 1

if (isTRUE(Sustainable == "TRUE")) {

  i = 2

}


Portfolio_Returns_Moments[1,i] = mean(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[2,i] = sd(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[3,i] = skewness(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[4,i] = kurtosis(Yearly_Portfolio_Return,na.rm = TRUE, method = "moment")


Portfolio_Returns_Moments[5,i] = median(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[6,i] = min(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[7,i] = max(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[8,i] = IQR(Yearly_Portfolio_Return,na.rm = TRUE)


Portfolio_Returns_Moments[9,i] = jarque.bera.test(Yearly_Portfolio_Return)


Portfolio_Returns_Moments[10,i] = sharpe(Yearly_Portfolio_Return, r = 0, scale = sqrt(1))


Portfolio_Returns_Moments[11,i] = quantile(Yearly_Portfolio_Return, 0.05)


Portfolio_Returns_Moments[12,i] = quantile(Yearly_Portfolio_Return, 0.01)

Portfolio_Returns_Moments[13,i] <- mean(Yearly_Portfolio_Return[Yearly_Portfolio_Return<=quantile(Yearly_Portfolio_Return, 0.05)])

Portfolio_Returns_Moments[14,i] <- mean(Yearly_Portfolio_Return[Yearly_Portfolio_Return<=quantile(Yearly_Portfolio_Return, 0.01)])


rownames(Portfolio_Returns_Moments) <- c("Mean return p.a. (%)", "SD p.a. (%)", "Skewness", "Kurtosis", "Median p.a. (%)", "Min", "Max", "IQR", "JB-stat", "Sharpe Ratio", "VaR 5%", "VaR 1%", "ES 5%", "ES 1%")

colnames(Portfolio_Returns_Moments) <- c("Market Portfolio","Sustainable Market Portfolio","Naive Portfolio")

print("MC simulation concluded successfully")

#####################################################################
#####################################################################
########################                    #########################
########################      PART 4_A      #########################
########################                    #########################
#####################################################################
#####################################################################

#Weights provided by betterment for each % level of stocks in the overall portfolios:

id <- "1lDyf1H-rrW4qPchXfRFnTt8kFMzmuDrp"

Weights_Betterment <- read.csv(sprintf("https://docs.google.com/uc?id=%s&export=download", id))

Weights_Betterment <- Filter(function(x)!all(is.na(x)), Weights_Betterment)
Weights_Betterment <- Weights_Betterment[1:nrow(Weights_Betterment) - 1,]

#We now move on to optimizing each portfolio for each iteration of the MC simulation based on the weights provided by betterment just uploaded in the environment

#First we need to create a vector with the names of the assets that we are going to optimize

Names <- colnames(Weights_Betterment)[2:12]
Names <- t(Names)
Names <- as.data.frame(Names)
colnames(Names) <- colnames(Weights_Betterment)[2:12]
#Weights_Betterment_Name <- Weights_Betterment[1,2:12]
#Names <- rbind(as.matrix(Names), Weights_Betterment_Name, stringsAsFactors = FALSE)

#Creating the necessary dataframes to increase efficiency

Returns_MC <- data.frame(matrix(nrow=nrow(`MC_Equity Emerging`)-1, ncol=nrow(Selected_ETFs)))

Weights_MC <- data.frame(matrix(nrow=Simulations, ncol=nrow(Selected_ETFs)))

Weights_Optimised_MC <- data.frame(matrix(nrow= nrow(Weights_Betterment), ncol=nrow(Selected_ETFs)))

#require(PortfolioAnalytics)

for(i in 1: nrow(Weights_Betterment)) {

  #Now before running optimisation we need returns from MC simulation of the assets

  #First to get the returns we need to create a matrix from the different asset classes simulations we ran before

  for(k in 2: Simulations+1) {

    EOD_Data_MC <- cbind(`MC_Equity US Total`[,k],`MC_Equity US Large`[,k], `MC_Equity US Mid`[,k], `MC_Equity US Small`[,k],`MC_Equity Emerging`[,k], `MC_Equity International`[,k], `MC_Bond Treasuries`[,k], `MC_Bond TIPS`[,k], `MC_Bond International`[,k], `MC_Bond High Quality`[,k], `MC_Bond Emerging`[,k])

    Seq_Days <- as.data.frame(Seq_Days)

    for (l in 1: nrow(Selected_ETFs)) {

      Returns_MC[,l] <- diff(EOD_Data_MC[,l])/EOD_Data_MC[,l][-length(EOD_Data_MC[,l])]

    }

    rownames(Returns_MC) <- Seq_Days[2:nrow(EOD_Data_MC),1]

    require(PortfolioAnalytics)

    pspec <- portfolio.spec(assets=colnames(Names))

    #Adding objective

    pspec <- add.objective(portfolio = pspec, type = "risk", name = "var")

    #Adding costraints

    pspec <- add.constraint(portfolio = pspec, type = "full_investment") #Sum weights = 1

    pspec <- add.constraint(portfolio=pspec, type="long_only") #No short positions

    #Stock & Bond % constraints (Group constraints)

    Stock_Min <- sum(Weights_Betterment[i, 2:7])*0.90
    Stock_Max <- sum(Weights_Betterment[i, 2:7])*1.10
    Treasuries_Min <- sum(Weights_Betterment[i, 8:10])*0.90
    Treasuries_Max <- sum(Weights_Betterment[i, 8:10])*1.10
    Bond_Min <- sum(Weights_Betterment[i, 11:12])*0.90
    Bond_Max <- sum(Weights_Betterment[i, 11:12])*1.10

    pspec <- add.constraint(portfolio=pspec, type="group", groups=list(groupA=c(1, 2, 3, 4, 5, 6), groupB=c(7, 8, 9), groupC=c(10, 11)), group_min=c(Stock_Min,Treasuries_Min, Bond_Min), group_max=c(Stock_Max,Treasuries_Max, Bond_Max))

    #To see constraints added please use: print(pspec)

    #Concentration, min and max on single assets constraints have not been implemented given the top and bottom portfolios (high % stocks and high % bonds) where the concentration is inherently high

    #Adding objective to min.Variance

    library(ROI)
    require(ROI.plugin.glpk)
    require(ROI.plugin.quadprog)

    opt_minvar <- optimize.portfolio(R=Returns_MC, portfolio=pspec, optimize_method="ROI", trace=TRUE)

    #Now we store the weights for each simulation to then take an average

    Weights_MC[(k-1),] <- opt_minvar$weights
  }

  #Now we can take an average

  Weight_Sim <- colMeans(Weights_MC,na.rm = TRUE)

  #Now we can store optimal weights for each portfolio level

  Weights_Optimised_MC[i,] <- Weight_Sim
  remove(pspec)
}

#Adding first column of Weights_Betterment to be consistent in the formatting

Weights_Optimised_MC <- cbind(Weights_Betterment[,1], Weights_Optimised_MC)

colnames(Weights_Optimised_MC) <- colnames(Weights_Betterment)

print("Weights optimization concluded successfully")

#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_A      #########################
########################                    #########################
#####################################################################
#####################################################################


#Now we turn to the rebalancing side of the portfolio: to do this we need to first establish the inputs for the rebalancing:

#1: Betterment Fee - 0.25% fee charged on a quarterly basis and calculate on the average balance over the period

Fee = 0.0025/4

#2: We will continue laying out the inputs according to Betterment's average investor with moderate income:

Age_Investor = Age_Investor

Initial_Investment = Initial_Investment #100'000 USD
Yearly_Contribution = 0 #No contribution to this portfolio

Monthly_Contribution = Yearly_Contribution/12

#3: From the age of the investor and according to Betterment's guidelines, we can derive the default time horizon and the age for the investor at the end of it

if (Age_Investor < 40) {Time_Horizon <- 50} else if (Age_Investor > 80) {Time_Horizon <- 10} else if (Age_Investor >= 40 && Age_Investor <= 80) {Time_Horizon <- 90 - Age_Investor}

Age_Investor_End <- Age_Investor + Time_Horizon

#4: Drift rate - Betterment defines it as the sum of the absolute differences between the optimised weights and the actual weights within the portfolio divided by 2: a level equal to or higher than the drift triggers rebalancing

Drift_Rate <- 0.03 # +/- 3%

#5: The dividend yield: all dividend are assumed to happen on a quarterly basis and this dividends will be reinvested in the portfolio so as to minimise the portfolio drift

Dividend_Yield <- Selected_ETFs[,23]

Dividend_Yield <- as.numeric(Dividend_Yield)/4

Dividend_Yield <- t(Dividend_Yield)

Dividend_Yield <- as.data.frame(Dividend_Yield)

colnames(Dividend_Yield) <- colnames(Weights_Betterment)[2:12]

#6: Net Expense Ratio single ETFs

Net_Expense_Ratio <- Selected_ETFs[,29]

Net_Expense_Ratio <- as.numeric(Net_Expense_Ratio)

Net_Expense_Ratio <- t(Net_Expense_Ratio)

Net_Expense_Ratio <- as.data.frame(Net_Expense_Ratio)

colnames(Net_Expense_Ratio) <- colnames(Weights_Betterment)[2:12]

for(i in 1:ncol(Net_Expense_Ratio)) {
  Net_Expense_Ratio[1,i] = 1 - (Net_Expense_Ratio[1,i]/4)
}

#7: Monthly withdrawal in case of Investor's Goal = 2 (Retirement Income) & Investor's Age greater or equal to 65

#We assume an average remaining life expectancy of 18 years after turning 65 for the investor

#the monthly withdrawal will be calculated when the investor is 65 years old and considering an annuity that will completely deplete his investment by the end of his expected life.

#A major contributor to the strategy is the goal of the investor

#The Goal can be 1,2,3,4,5 representing respectively:

# 1: Retirement Savings: for investors saving for retirement
# 2: Retirement Income: for investors making regular withdrawals
# 3: Safety Net: for investors who want an emergency fund
# 4: Major Purchase: to make a future large expenditure
# 5: General Investing: when the investor is not sure about the objective

Investor_Goal <- Investor_Goal

### Inputs necessary for GOAL 1 - Retirement Savings

if (isTRUE(Investor_Goal == 1)) {Bond_Level <- 0.30
Stock_Level <- 0.70}

#Liquidating 50% of their portfolio – Half liquidation all at once after 30 years (age 65)

### Inputs necessary for GOAL 2 - Retirement Income

if (isTRUE(Investor_Goal == 2)) {Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))/100
Bond_Level <- 1- Stock_Level}

### Inputs necessary for GOAL 3

# holding at 15% stocks, 85% bonds continuously

if (isTRUE(Investor_Goal == 3)) {Bond_Level <- 0.15
Stock_Level <- 0.85
}

### Inputs necessary for GOAL 4

# From 90% stocks to 40% stocks when the investor is 3 years from major purchase then 32%, 28% and 5% during the last year

Years_To_Investment <- 15  #Number of years to planned investment

if (isTRUE(Investor_Goal == 4)) {if (Years_To_Investment == 1) {Bond_Level <- 0.95
Stock_Level <- 0.05}
  else if (Years_To_Investment == 2) {Bond_Level <- 0.72
  Stock_Level <- 0.28}
  else if (Years_To_Investment == 3) {Bond_Level <- 0.68
  Stock_Level <- 0.32}
  else if (Years_To_Investment > 15) {Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))/100
  Bond_Level <- 1- Stock_Level}
  else if (Years_To_Investment < 15 & Years_To_Investment > 3) {Stock_Level <- round(90-((90-40)/(15-4))*(15 - Years_To_Investment))/100
  Bond_Level <- 1- Stock_Level}}

### Inputs necessary for GOAL 5


#90% stocks until 45 yo
#Then decreasing line until 65yo to 55% stocks
#Then straight line

if (isTRUE(Investor_Goal == 5)) {if (65 - Age_Investor >= 20) {Bond_Level <- 0.10
Stock_Level <- 0.90}
  else  if (65 - Age_Investor < 20 & 65 - Age_Investor >0) {Stock_Level <- round(90-((90-55)/(65-45))*(Age_Investor-45))/100
  Bond_Level <- 1- Stock_Level}
  else  if (65 - Age_Investor <=0) {Stock_Level <- 0.55
  Bond_Level <- 0.45}}


#To be noted: Betterment forecasts the balance on a yearly increment basis, whereas allocation changes are forecasted on a monthly basis. If remaining time is less than one year, the assumption that the investment remains at the end of this period is made and therefore the allocation is kept throughout the year. Rebalancing, on the other hand, is done on a daily basis.




#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_B      #########################
########################                    #########################
#####################################################################
#####################################################################

# Now that the goals have been set, we move on to forecasting the rebalancing of the portfolio on a daily basis.

# As a first step we create a dataframe with the time horizon of the investment for the investor and then we fill it in step-by-step with our inputs

Starting_Date <- Start
End_Date <- End
holidays = holidayNYSE()
Seq_Days = as.timeDate(seq(from = Starting_Date, to = End_Date, by = "day"))
Seq_Days <- Seq_Days[isBizday(Seq_Days, holidays = holidays, wday = 1:5)]
Seq_Days <- Seq_Days[1:nrow(Stock_Prices)]
Seq_Days <- as.data.frame(Seq_Days)
Seq_Days <- Seq_Days[1:nrow(ETF_EOD_Data),]
Seq_Days <- as.data.frame(Seq_Days)

Rebalancing_Input <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 7 ))
Rebalancing_Input[,1] <- Seq_Days[,1]
colnames(Rebalancing_Input)[1] = "Date"


# Now we create:

# in the second column a Yes/No vector which says if the day is the last business day of the month;
# a third column which says whether this is the last day of the quarter

# a fourth column which says if it is the last day of the year

# a fifth column which says the remaining time horizon in years rounded downwards

# a sixth column with Betterment's fee

# and a sevent column with the age of the investor

for(i in 1: nrow(Rebalancing_Input)) {

  #Second column

  if (isTRUE(months.Date(Rebalancing_Input[i,1]) != months.Date(Rebalancing_Input[i+1,1]))) {Rebalancing_Input[i,2] = "Yes"}


  #Third column

  if (isTRUE(quarters.Date(Rebalancing_Input[i,1]) != quarters.Date(Rebalancing_Input[i+1,1]))) {Rebalancing_Input[i,3] = "Yes"}


  #Fourth column

  End_Date_Investment <- nrow(Rebalancing_Input) #Last day of the investment

  Rebalancing_Input[i,4] <- ceiling((Rebalancing_Input[End_Date_Investment,1] - Rebalancing_Input[i,1])/365)

  #Now we move on to inserting the monthly contribution in a fifth column

  if (isTRUE(Rebalancing_Input[i,2] == "Yes")) {Rebalancing_Input[i,5] = round(Yearly_Contribution/12,2)}

  #Adding the Betterment Fee every quarter in a sixth column

  if (isTRUE(Rebalancing_Input[i,3] == "Yes")) {Rebalancing_Input[i,6] = Fee}

  #Adding the age of the investor as a 7th column

  Rebalancing_Input[i,7] <- floor(Age_Investor + (Rebalancing_Input[i,1]-Rebalancing_Input[1,1])/365)

}


colnames(Rebalancing_Input)[2:7] = c("End of Month", "End of Quarter", "Remaining years","Contribution","Betterment Fee", "Investor's Age")

#Now we need to create as a last input the optimal weights dataframe that depends on the age of the investor

#To do this we need to do it in 5 if-loops that comprise the 5 investment goals that betterment allows

Weights_Goal <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 2 ))
colnames(Weights_Goal) <- c("Stock Level", "Bond Level")

#First Goal

if (isTRUE(Investor_Goal == 1)) {for(i in 1:nrow(Weights_Goal))

  Weights_Goal[i,] <- c(70,30)

}

#Second Goal

if (isTRUE(Investor_Goal == 2)) {for(i in 1:nrow(Weights_Goal)) {

  if (isTRUE(65 - Rebalancing_Input[i,7] <= 0 & Rebalancing_Input[i,7] <= 80)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(Rebalancing_Input[i,7] > 80)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(65 -  Rebalancing_Input[i,7] >= 20)) {Weights_Goal[i,] <- c(90,10)}

  else  if (isTRUE(65 - Rebalancing_Input[i,7] < 20 & 65 - Rebalancing_Input[i,7] > 0)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Rebalancing_Input[i,7]-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

}}

#Third Goal

if (isTRUE(Investor_Goal == 3)) {for(i in 1:nrow(Weights_Goal)) {
  Stock_Level <- 0.15
  Bond_Level <- 0.85
  Weights_Goal[i,] <- c(Stock_Level,Bond_Level)

}}

#Fourth Goal

if (isTRUE(Investor_Goal == 4)) { for(i in 1:nrow(Weights_Goal)) {

  if (isTRUE(Rebalancing_Input[i,4] <= 1)) {
    Bond_Level <- 95
    Stock_Level <- 5
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
  else if (isTRUE(Rebalancing_Input[i,4] == 2)) {
    Bond_Level <- 72
    Stock_Level <- 28
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(Rebalancing_Input[i,4] == 3)) {
    Bond_Level <- 68
    Stock_Level <- 32
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(Rebalancing_Input[i,4] > 15)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
  else if (isTRUE(Rebalancing_Input[i,4] < 15 & Years_To_Investment > 3)) {
    Stock_Level <- round(90-((90-40)/(15-4))*(15 - Years_To_Investment))/100
    Bond_Level <- 1- Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
}}


#Fifth Goal

if (isTRUE(Investor_Goal == 5)) {for(i in 1:nrow(Weights_Goal)) {

  if (isTRUE(65 - Rebalancing_Input[i,7] >= 20)) {
    Bond_Level <- 10
    Stock_Level <- 90
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else  if (isTRUE(65 - Rebalancing_Input[i,7] < 20 & 65 - Rebalancing_Input[i,7] >0)) {
    Stock_Level <- round(90-((90-55)/(65-45))*(Rebalancing_Input[i,7] -45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else  if (isTRUE(65 - Rebalancing_Input[i,7] <=0)) {
    Stock_Level <- 55
    Bond_Level <- 45
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
}}



#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_C      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now we turn to rebalancing and we will use the average that we calculated as a possible evolution of prices



Rebalancing_Simulation <- cbind(Seq_Days,ETF_EOD_Data)

Rebalancing_Simulation <- as.data.frame(Rebalancing_Simulation)

colnames(Rebalancing_Simulation) <- colnames(Weights_Optimised_MC)

colnames(Rebalancing_Simulation)[1] = "Date"

Rebalancing_Simulation[,1] <- Rebalancing_Input[1:nrow(Rebalancing_Simulation),1]

#Now we move to the goal based weight allocation. We will therefore do all the process within an IF loop for each of the 5 goals.

#First we create Matrix with the weights that the investor should have in each day for the investment's horizon.

Rebalancing_Weights <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = nrow(Selected_ETFs)+1 ))

Rebalancing_Weights[,1] <- Rebalancing_Input[,1]

colnames(Rebalancing_Weights)[1] <- "Date"

colnames(Rebalancing_Weights)[2:12] <- colnames(Weights_Optimised_MC)[2:12]

#Row number for weights

Nrow_Weights <- Weights_Goal[1,1] + 1
Rebalancing_Weights[1,2:ncol(Rebalancing_Weights)] <- Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

#The other columns in the dataframe with the weights will be filled one by one while the stock price progresses to check the actual weights given the price evolution and whether a rebalancing is necessary

#Now we create the dataframe where we have the exact amount invested in each ETF

Rebalancing_Portfolio_Value <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = nrow(Selected_ETFs)+1 ))

Rebalancing_Portfolio_Value[,1] <- Rebalancing_Input[,1]

colnames(Rebalancing_Portfolio_Value)[1] <- "Date"

colnames(Rebalancing_Portfolio_Value)[2:12] <- colnames(Weights_Optimised_MC)[2:12]

#Now we fill the first row of the dataframe with the initial value of each asset class

Rebalancing_Portfolio_Value[1,2:ncol(Rebalancing_Portfolio_Value)] <- round(Initial_Investment*Rebalancing_Weights[1,2:ncol(Rebalancing_Weights)],2)

#Now we create the dataframe with the amounch of "shares" in each etf, we will round to 2 decimals as Betterment explicitly says they use fractional shares

Rebalancing_Shares <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = nrow(Selected_ETFs)+1 ))

Rebalancing_Shares[,1] <- Rebalancing_Input[,1]

colnames(Rebalancing_Shares)[1] <- "Date"

colnames(Rebalancing_Shares)[2:12] <- colnames(Weights_Optimised_MC)[2:12]

#and we fill it in with the different shares by dividing portfolio value by prices of single ETFs

Rebalancing_Shares[1,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[1,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[1, 2:ncol(Rebalancing_Simulation)],2)





#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_D      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now that we have prepared all the necessary inputs and dataframes we can move to the actual rebalancing part

#This, as explained, will be done within an if loop to check the investor's goal

#First this loop for all investments goals expect for the retirement income goal

for (i in 2:nrow(Rebalancing_Simulation)) {
  #First we recalculate the portfolio value and the weights based on the new prices

  Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = Rebalancing_Shares[i-1,2:ncol(Rebalancing_Shares)]

  Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] = Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] * Rebalancing_Simulation[i,2:ncol(Rebalancing_Simulation)]

  Rebalancing_Weights[i,2:ncol(Rebalancing_Portfolio_Value)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

  if (isTRUE(Rebalancing_Input[i,2] == "Yes"))  {

    if (isTRUE(Rebalancing_Input[i,3] == "Yes")) {

      #first we deduct Betterment's fee at the end of every quarter
      Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] =     Rebalancing_Portfolio_Value[i-1,2:ncol(Rebalancing_Portfolio_Value)]*(1-Rebalancing_Input[i,6])

      #Then we subtract the ETFs' fees that we assumed are charged on a quarterly basis for each ETF in the portfolio

      Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] * Net_Expense_Ratio[1,]

      #After having subtracted the fees we check the relative weights that have been created as a consequence of the single fees of the ETFs and Betterment's fee

      Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]/sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

      #and we also recalculate the number of shares left for each ETF after these 2 fees

      Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[i, 2:ncol(Rebalancing_Simulation)],2)

      #Before going to the monthly contribution, since this is the quarterly loop, we calculate the sum of the dividends that are paid by the ETFs

      Dividend_Paid = Dividend_Yield * Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]

      Sum_Dividend_Paid = sum(Dividend_Paid)

    } # end if loop for Rebalancing_Input[i,3]

    #So as a first step we check which weight is more different from what it should be

    Nrow_Weights <- Weights_Goal[i,1] + 1 #by using Weights goal we automatically use the weights corresponding to the right values for investor's goal and time horizon

    Rebalancing_Difference = Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] - Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

    #Now that we have the differences between what it should be and what it is we can move to if there is a monthly contribution today

    #We define what the max difference means in terms of contribution and its position within Rebalancing difference

    Min_Difference = suppressWarnings(min(Rebalancing_Difference, na.rm = TRUE))

    #we need to take the min of the negative (i.e. the one where the weight is less than what it should be)

    Element_Min = which(Rebalancing_Difference==suppressWarnings(min(Rebalancing_Difference,na.rm = TRUE)))

    Col_Number_Element_Min = Element_Min + 1

    Min_Difference_Absolute = Min_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Min]

    if(isTRUE(Investor_Goal==1|Investor_Goal==3|Investor_Goal==4|Investor_Goal==5)) {

      Monthly_Contribution = Monthly_Contribution + Sum_Dividend_Paid

    } else {Monthly_Contribution = Sum_Dividend_Paid}

    #Now we define if the monthly contribution if greater then the largest portfolio difference in absolute values

    if (isTRUE(abs(Min_Difference_Absolute) >= Monthly_Contribution)) {

      Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] = Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] + Monthly_Contribution

    } else if(isTRUE(abs(Min_Difference_Absolute) < Monthly_Contribution))  {

      while (Monthly_Contribution > 0 ) {

        #We calculate the initial difference to the underweighted asset

        Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] = Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] - Min_Difference_Absolute

        # Leftover of monthly contribution

        Monthly_Contribution = Monthly_Contribution - abs(Min_Difference_Absolute)

        #to then search for second largest difference

        Rebalancing_Difference[1,Element_Min] = NA

        Min_Difference = suppressWarnings(min(Rebalancing_Difference,na.rm = TRUE)) #we need to take the max of the negative (i.e. the one where the weight is less than what it should be)

        Element_Min = which(Rebalancing_Difference==suppressWarnings(min(Rebalancing_Difference,na.rm = TRUE)))



        Min_Difference_Absolute = Min_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Min]

        #Now we take the minimum between the left monthly contribution and the available contribution for this asset

        Min_Difference_Absolute = suppressWarnings(min(abs(Min_Difference_Absolute),Monthly_Contribution))

      } # end while loop
    } #end else if Min_Difference_Absolute < Monthly_Contribution

    #Now we add also the withdrawal in case investor's goal = 2

    if (isTRUE(Rebalancing_Input[i,7] >= 65 & Investor_Goal == 2)) {

      Monthly_Withdrawal = ((0.02*(sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Difference_Value)]))/(1-1.02^-(83 - Rebalancing_Input[i,7]))))/12

      #we assume r to be equal to 2%, in line with the 10y rate on US treasury notes

      while (isTRUE(Monthly_Withdrawal > 0)) {

        #We calculate the initial difference to the underweighted asset

        Nrow_Weights <- Weights_Goal[i,1] + 1 #by using Weights goal we automatically use the weights corresponding to the right values for investor's goal and time horizon

        Rebalancing_Difference = Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] - Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

        Max_Difference = suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE))

        Element_Max = which(Rebalancing_Difference==suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE)))

        Col_Number_Element_Max = Element_Max + 1

        Max_Difference_Absolute = Max_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Max]

        Rebalancing_Portfolio_Value[i,Col_Number_Element_Max] = Rebalancing_Portfolio_Value[i,Col_Number_Element_Max] - Max_Difference_Absolute

        # Leftover of monthly contribution

        Monthly_Withdrawal = Monthly_Withdrawal - Max_Difference_Absolute

        #to then search for second largest difference

        Rebalancing_Difference[1,Element_Max] = NA

        Max_Difference = suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE)) #we need to take the max of the positive (i.e. the one where the weight is less than what it should be)

        Element_Max = which(Rebalancing_Difference==suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE)))

        Max_Difference_Absolute = Max_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Max]

        #Now we take the maximum between the left monthly monthly withdrawal and the available contribution for this asset

        Max_Difference_Absolute = suppressWarnings(max(Max_Difference_Absolute,Monthly_Withdrawal))

      } # end while loop
    } # end for loop for withdrawal for a retired investor
  } #end if loop for Rebalancing_Input[i,2]

  Sum_Dividend_Paid = 0 #to reset value for the dividends

  #and we also recalculate the number of shares left for each ETF after monthly contribution and dividends

  Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[i, 2:ncol(Rebalancing_Simulation)],2)

  #Now we do the daily rebalancing, and for this we will need to calculate the portfolio drift as defined by Betterement. if it is >= 3% than we will rebalance, otherwise no.

  #Betterment defines it as the sum of the absolute differences between the optimised weights and the actual weights within the portfolio divided by 2: a level equal to or higher than the drift triggers rebalancing

  #So, let's calculate the portfolio drift, to do it we first need the updated portfolio weights

  Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]/sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

  #Now that we have the updated weights we can calculate the drift as the absolute difference w.r.t. the weights optimised divided by 2

  Nrow_Weights <- Weights_Goal[i,1] + 1
  Actual_Drift = sum(abs(Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] - Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)])/2)

  #Now we chech if the drift is greater or equal to 3%

  if (isTRUE(Actual_Drift >= Drift_Rate)) {

    #since rebalanced is triggered then we calculate the portfolio values as per optimal weights

    Rebalancing_Portfolio_Value_Optimal = sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])*Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

    #Now we calculate the difference w.r.t. the values before

    Rebalancing_Difference_Value =  Rebalancing_Portfolio_Value_Optimal - Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]

    #and this are the values of what needs to be sold and bought to rebalance the portfolio.

    #Now we substitute the Rebalancing_Portfolio_Value_Optimal Rebalancing_Portfolio_Value to have the optimal values.

    Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] <- Rebalancing_Portfolio_Value_Optimal

    #And to finish rebalancing we recalculate weights and shares number

    Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]/sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

    Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[i, 2:ncol(Rebalancing_Simulation)],2)


  } #end if loop that triggers rebalancing

  Monthly_Contribution = Yearly_Contribution/12

} #end for loop for all the rows

#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_E      #########################
########################                    #########################
#####################################################################
#####################################################################

#Plotting value of Portfolio Overtime and value of single assets overtime

#First we plot single assets:

require(ggplot2)
require(reshape2)

Rebalancing_Portfolio_Value_Melted <- melt(Rebalancing_Portfolio_Value, id.var='Date')

png(filename="Rebalancing_ETFs_Plot.png")

print(ggplot(Rebalancing_Portfolio_Value_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Value in Portfolio') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

dev.off()

print(ggplot(Rebalancing_Portfolio_Value_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Value in Portfolio [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

#Now we can print portfolio value overtime

Total_Portfolio_Value <- data.frame(matrix(nrow=nrow(Rebalancing_Portfolio_Value), ncol = 2 ))

for(i in 1:nrow(Rebalancing_Portfolio_Value)) {

  Total_Portfolio_Value[i,2] =  sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

}

Total_Portfolio_Value[,1] <- Rebalancing_Portfolio_Value[,1]

colnames(Total_Portfolio_Value) <- c("Date", "value")

png(filename="Portfolio_Overtime.png")

print(ggplot(Total_Portfolio_Value, aes(x=Date, y=value)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

dev.off()

print(ggplot(Total_Portfolio_Value, aes(x=Date, y=value)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))




print("Rebalancing concluded successfully")


#Now the following part will be carried out only if the user sets Comparison to TRUE

if (isTRUE(Comparison == "TRUE")) {

#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_A      #########################
########################                    #########################
#####################################################################
#####################################################################


#Now we turn to the rebalancing side of the portfolio: to do this we need to first establish the inputs for the rebalancing:

#1: Betterment Fee - 0.25% fee charged on a quarterly basis and calculate on the average balance over the period

Fee = 0.0025/4

#2: We will continue laying out the inputs according to Betterment's average investor with moderate income:

Age_Investor = Age_Investor

Initial_Investment = Initial_Investment #100'000 USD
Yearly_Contribution = 0 #No contribution to this portfolio

Monthly_Contribution = Yearly_Contribution/12

#3: From the age of the investor and according to Betterment's guidelines, we can derive the default time horizon and the age for the investor at the end of it

if (Age_Investor < 40) {Time_Horizon <- 50} else if (Age_Investor > 80) {Time_Horizon <- 10} else if (Age_Investor >= 40 && Age_Investor <= 80) {Time_Horizon <- 90 - Age_Investor}

Age_Investor_End <- Age_Investor + Time_Horizon

#4: Drift rate - Betterment defines it as the sum of the absolute differences between the optimised weights and the actual weights within the portfolio divided by 2: a level equal to or higher than the drift triggers rebalancing

Drift_Rate <- 0.03 # +/- 3%

#5: The dividend yield: all dividend are assumed to happen on a quarterly basis and this dividends will be reinvested in the portfolio so as to minimise the portfolio drift

Dividend_Yield <- Selected_ETFs[,23]

Dividend_Yield <- as.numeric(Dividend_Yield)/4

Dividend_Yield <- t(Dividend_Yield)

Dividend_Yield <- as.data.frame(Dividend_Yield)

colnames(Dividend_Yield) <- colnames(Weights_Betterment)[2:12]

#6: Net Expense Ratio single ETFs

Net_Expense_Ratio <- Selected_ETFs[,29]

Net_Expense_Ratio <- as.numeric(Net_Expense_Ratio)

Net_Expense_Ratio <- t(Net_Expense_Ratio)

Net_Expense_Ratio <- as.data.frame(Net_Expense_Ratio)

colnames(Net_Expense_Ratio) <- colnames(Weights_Betterment)[2:12]

for(i in 1:ncol(Net_Expense_Ratio)) {
  Net_Expense_Ratio[1,i] = 1 - (Net_Expense_Ratio[1,i]/4)
}

#7: Monthly withdrawal in case of Investor's Goal = 2 (Retirement Income) & Investor's Age greater or equal to 65

#We assume an average remaining life expectancy of 18 years after turning 65 for the investor

#the monthly withdrawal will be calculated when the investor is 65 years old and considering an annuity that will completely deplete his investment by the end of his expected life.

#A major contributor to the strategy is the goal of the investor

#The Goal can be 1,2,3,4,5 representing respectively:

# 1: Retirement Savings: for investors saving for retirement
# 2: Retirement Income: for investors making regular withdrawals
# 3: Safety Net: for investors who want an emergency fund
# 4: Major Purchase: to make a future large expenditure
# 5: General Investing: when the investor is not sure about the objective


### Inputs necessary for GOAL 1 - Retirement Savings

if (isTRUE(Investor_Goal == 1)) {Bond_Level <- 0.30
Stock_Level <- 0.70}

#Liquidating 50% of their portfolio – Half liquidation all at once after 30 years (age 65)

### Inputs necessary for GOAL 2 - Retirement Income

if (isTRUE(Investor_Goal == 2)) {Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))/100
Bond_Level <- 1- Stock_Level}

### Inputs necessary for GOAL 3

# holding at 15% stocks, 85% bonds continuously

if (isTRUE(Investor_Goal == 3)) {Bond_Level <- 0.15
Stock_Level <- 0.85
}

### Inputs necessary for GOAL 4

# From 90% stocks to 40% stocks when the investor is 3 years from major purchase then 32%, 28% and 5% during the last year

Years_To_Investment <- 15  #Number of years to planned investment

if (isTRUE(Investor_Goal == 4)) {if (Years_To_Investment == 1) {Bond_Level <- 0.95
Stock_Level <- 0.05}
  else if (Years_To_Investment == 2) {Bond_Level <- 0.72
  Stock_Level <- 0.28}
  else if (Years_To_Investment == 3) {Bond_Level <- 0.68
  Stock_Level <- 0.32}
  else if (Years_To_Investment > 15) {Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))/100
  Bond_Level <- 1- Stock_Level}
  else if (Years_To_Investment < 15 & Years_To_Investment > 3) {Stock_Level <- round(90-((90-40)/(15-4))*(15 - Years_To_Investment))/100
  Bond_Level <- 1- Stock_Level}}

### Inputs necessary for GOAL 5


#90% stocks until 45 yo
#Then decreasing line until 65yo to 55% stocks
#Then straight line

if (isTRUE(Investor_Goal == 5)) {if (65 - Age_Investor >= 20) {Bond_Level <- 0.10
Stock_Level <- 0.90}
  else  if (65 - Age_Investor < 20 & 65 - Age_Investor >0) {Stock_Level <- round(90-((90-55)/(65-45))*(Age_Investor-45))/100
  Bond_Level <- 1- Stock_Level}
  else  if (65 - Age_Investor <=0) {Stock_Level <- 0.55
  Bond_Level <- 0.45}}


#To be noted: Betterment forecasts the balance on a yearly increment basis, whereas allocation changes are forecasted on a monthly basis. If remaining time is less than one year, the assumption that the investment remains at the end of this period is made and therefore the allocation is kept throughout the year. Rebalancing, on the other hand, is done on a daily basis.

#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_B      #########################
########################                    #########################
#####################################################################
#####################################################################

# Now that the goals have been set, we move on to forecasting the rebalancing of the portfolio on a daily basis.

# As a first step we create a dataframe with the time horizon of the investment for the investor and then we fill it in step-by-step with our inputs

Starting_Date <- Start
End_Date <- End
holidays = holidayNYSE()
Seq_Days = as.timeDate(seq(from = Starting_Date, to = End_Date, by = "day"))
Seq_Days <- Seq_Days[isBizday(Seq_Days, holidays = holidays, wday = 1:5)]
Seq_Days <- Seq_Days[1:nrow(Stock_Prices)]
Seq_Days <- as.data.frame(Seq_Days)
Seq_Days <- Seq_Days[1:nrow(ETF_EOD_Data),]
Seq_Days <- as.data.frame(Seq_Days)

Rebalancing_Input <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 7 ))
Rebalancing_Input[,1] <- Seq_Days[,1]
colnames(Rebalancing_Input)[1] = "Date"


# Now we create:

# in the second column a Yes/No vector which says if the day is the last business day of the month;
# a third column which says whether this is the last day of the quarter

# a fourth column which says if it is the last day of the year

# a fifth column which says the remaining time horizon in years rounded downwards

# a sixth column with Betterment's fee

# and a sevent column with the age of the investor

for(i in 1: nrow(Rebalancing_Input)) {

  #Second column

  if (isTRUE(months.Date(Rebalancing_Input[i,1]) != months.Date(Rebalancing_Input[i+1,1]))) {Rebalancing_Input[i,2] = "Yes"}


  #Third column

  if (isTRUE(quarters.Date(Rebalancing_Input[i,1]) != quarters.Date(Rebalancing_Input[i+1,1]))) {Rebalancing_Input[i,3] = "Yes"}


  #Fourth column

  End_Date_Investment <- nrow(Rebalancing_Input) #Last day of the investment

  Rebalancing_Input[i,4] <- ceiling((Rebalancing_Input[End_Date_Investment,1] - Rebalancing_Input[i,1])/365)

  #Now we move on to inserting the monthly contribution in a fifth column

  if (isTRUE(Rebalancing_Input[i,2] == "Yes")) {Rebalancing_Input[i,5] = round(Yearly_Contribution/12,2)}

  #Adding the Betterment Fee every quarter in a sixth column

  if (isTRUE(Rebalancing_Input[i,3] == "Yes")) {Rebalancing_Input[i,6] = Fee}

  #Adding the age of the investor as a 7th column

  Rebalancing_Input[i,7] <- floor(Age_Investor + (Rebalancing_Input[i,1]-Rebalancing_Input[1,1])/365)

}


colnames(Rebalancing_Input)[2:7] = c("End of Month", "End of Quarter", "Remaining years","Contribution","Betterment Fee", "Investor's Age")

#Now we need to create as a last input the optimal weights dataframe that depends on the age of the investor

#To do this we need to do it in 5 if-loops that comprise the 5 investment goals that betterment allows

Weights_Goal <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 2 ))
colnames(Weights_Goal) <- c("Stock Level", "Bond Level")

#First Goal

if (isTRUE(Investor_Goal == 1)) {for(i in 1:nrow(Weights_Goal))

  Weights_Goal[i,] <- c(70,30)

}

#Second Goal

if (isTRUE(Investor_Goal == 2)) {for(i in 1:nrow(Weights_Goal)) {

  if (isTRUE(65 - Rebalancing_Input[i,7] <= 0 & Rebalancing_Input[i,7] <= 80)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(Rebalancing_Input[i,7] > 80)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(65 -  Rebalancing_Input[i,7] >= 20)) {Weights_Goal[i,] <- c(90,10)}

  else  if (isTRUE(65 - Rebalancing_Input[i,7] < 20 & 65 - Rebalancing_Input[i,7] > 0)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Rebalancing_Input[i,7]-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

}}

#Third Goal

if (isTRUE(Investor_Goal == 3)) {for(i in 1:nrow(Weights_Goal)) {
  Stock_Level <- 0.15
  Bond_Level <- 0.85
  Weights_Goal[i,] <- c(Stock_Level,Bond_Level)

}}

#Fourth Goal

if (isTRUE(Investor_Goal == 4)) { for(i in 1:nrow(Weights_Goal)) {

  if (isTRUE(Rebalancing_Input[i,4] <= 1)) {
    Bond_Level <- 95
    Stock_Level <- 5
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
  else if (isTRUE(Rebalancing_Input[i,4] == 2)) {
    Bond_Level <- 72
    Stock_Level <- 28
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(Rebalancing_Input[i,4] == 3)) {
    Bond_Level <- 68
    Stock_Level <- 32
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else if (isTRUE(Rebalancing_Input[i,4] > 15)) {
    Stock_Level <- round(90-((90-30)/(80-45))*(Age_Investor-45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
  else if (isTRUE(Rebalancing_Input[i,4] < 15 & Years_To_Investment > 3)) {
    Stock_Level <- round(90-((90-40)/(15-4))*(15 - Years_To_Investment))/100
    Bond_Level <- 1- Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
}}


#Fifth Goal

if (isTRUE(Investor_Goal == 5)) {for(i in 1:nrow(Weights_Goal)) {

  if (isTRUE(65 - Rebalancing_Input[i,7] >= 20)) {
    Bond_Level <- 10
    Stock_Level <- 90
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else  if (isTRUE(65 - Rebalancing_Input[i,7] < 20 & 65 - Rebalancing_Input[i,7] >0)) {
    Stock_Level <- round(90-((90-55)/(65-45))*(Rebalancing_Input[i,7] -45))
    Bond_Level <- 100 - Stock_Level
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }

  else  if (isTRUE(65 - Rebalancing_Input[i,7] <=0)) {
    Stock_Level <- 55
    Bond_Level <- 45
    Weights_Goal[i,] <- c(Stock_Level,Bond_Level)
  }
}}




#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_C      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now we turn to rebalancing and we will use the average that we calculated as a possible evolution of prices



Rebalancing_Simulation <- cbind(Seq_Days,ETF_EOD_Data)

Rebalancing_Simulation <- as.data.frame(Rebalancing_Simulation)

colnames(Rebalancing_Simulation) <- colnames(Weights_Optimised_MC)

colnames(Rebalancing_Simulation)[1] = "Date"

Rebalancing_Simulation[,1] <- Rebalancing_Input[1:nrow(Rebalancing_Simulation),1]

#Now we move to the goal based weight allocation. We will therefore do all the process within an IF loop for each of the 5 goals.

#First we create Matrix with the weights that the investor should have in each day for the investment's horizon.

Rebalancing_Weights <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = nrow(Selected_ETFs)+1 ))

Rebalancing_Weights[,1] <- Rebalancing_Input[,1]

colnames(Rebalancing_Weights)[1] <- "Date"

colnames(Rebalancing_Weights)[2:12] <- colnames(Weights_Optimised_MC)[2:12]

#Row number for weights

Nrow_Weights <- Weights_Goal[1,1] + 1
Rebalancing_Weights[1,2:ncol(Rebalancing_Weights)] <- Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

#The other columns in the dataframe with the weights will be filled one by one while the stock price progresses to check the actual weights given the price evolution and whether a rebalancing is necessary

#Now we create the dataframe where we have the exact amount invested in each ETF

Rebalancing_Portfolio_Value <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = nrow(Selected_ETFs)+1 ))

Rebalancing_Portfolio_Value[,1] <- Rebalancing_Input[,1]

colnames(Rebalancing_Portfolio_Value)[1] <- "Date"

colnames(Rebalancing_Portfolio_Value)[2:12] <- colnames(Weights_Optimised_MC)[2:12]

#Now we fill the first row of the dataframe with the initial value of each asset class

Rebalancing_Portfolio_Value[1,2:ncol(Rebalancing_Portfolio_Value)] <- round(Initial_Investment*Rebalancing_Weights[1,2:ncol(Rebalancing_Weights)],2)

#Now we create the dataframe with the amounch of "shares" in each etf, we will round to 2 decimals as Betterment explicitly says they use fractional shares

Rebalancing_Shares <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = nrow(Selected_ETFs)+1 ))

Rebalancing_Shares[,1] <- Rebalancing_Input[,1]

colnames(Rebalancing_Shares)[1] <- "Date"

colnames(Rebalancing_Shares)[2:12] <- colnames(Weights_Optimised_MC)[2:12]

#and we fill it in with the different shares by dividing portfolio value by prices of single ETFs

Rebalancing_Shares[1,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[1,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[1, 2:ncol(Rebalancing_Simulation)],2)






#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_D      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now that we have prepared all the necessary inputs and dataframes we can move to the actual rebalancing part

#This, as explained, will be done within an if loop to check the investor's goal

#First this loop for all investments goals expect for the retirement income goal

for (i in 2:nrow(Rebalancing_Simulation)) {
  #First we recalculate the portfolio value and the weights based on the new prices

  Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = Rebalancing_Shares[i-1,2:ncol(Rebalancing_Shares)]

  Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] = Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] * Rebalancing_Simulation[i,2:ncol(Rebalancing_Simulation)]

  Rebalancing_Weights[i,2:ncol(Rebalancing_Portfolio_Value)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

  if (isTRUE(Rebalancing_Input[i,2] == "Yes"))  {

    if (isTRUE(Rebalancing_Input[i,3] == "Yes")) {

      #first we deduct Betterment's fee at the end of every quarter
      Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] =     Rebalancing_Portfolio_Value[i-1,2:ncol(Rebalancing_Portfolio_Value)]*(1-Rebalancing_Input[i,6])

      #Then we subtract the ETFs' fees that we assumed are charged on a quarterly basis for each ETF in the portfolio

      Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] * Net_Expense_Ratio[1,]

      #After having subtracted the fees we check the relative weights that have been created as a consequence of the single fees of the ETFs and Betterment's fee

      Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]/sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

      #and we also recalculate the number of shares left for each ETF after these 2 fees

      Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[i, 2:ncol(Rebalancing_Simulation)],2)

      #Before going to the monthly contribution, since this is the quarterly loop, we calculate the sum of the dividends that are paid by the ETFs

      Dividend_Paid = Dividend_Yield * Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]

      Sum_Dividend_Paid = sum(Dividend_Paid)

    } # end if loop for Rebalancing_Input[i,3]

    #So as a first step we check which weight is more different from what it should be

    Nrow_Weights <- Weights_Goal[i,1] + 1 #by using Weights goal we automatically use the weights corresponding to the right values for investor's goal and time horizon

    Rebalancing_Difference = Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] - Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

    #Now that we have the differences between what it should be and what it is we can move to if there is a monthly contribution today

    #We define what the max difference means in terms of contribution and its position within Rebalancing difference

    Min_Difference = suppressWarnings(min(Rebalancing_Difference, na.rm = TRUE))

    #we need to take the min of the negative (i.e. the one where the weight is less than what it should be)

    Element_Min = which(Rebalancing_Difference==suppressWarnings(min(Rebalancing_Difference,na.rm = TRUE)))

    Col_Number_Element_Min = Element_Min + 1

    Min_Difference_Absolute = Min_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Min]

    if(isTRUE(Investor_Goal==1|Investor_Goal==3|Investor_Goal==4|Investor_Goal==5)) {

      Monthly_Contribution = Monthly_Contribution + Sum_Dividend_Paid

    } else {Monthly_Contribution = Sum_Dividend_Paid}

    #Now we define if the monthly contribution if greater then the largest portfolio difference in absolute values

    if (isTRUE(abs(Min_Difference_Absolute) >= Monthly_Contribution)) {

      Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] = Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] + Monthly_Contribution

    } else if(isTRUE(abs(Min_Difference_Absolute) < Monthly_Contribution))  {

      while (Monthly_Contribution > 0 ) {

        #We calculate the initial difference to the underweighted asset

        Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] = Rebalancing_Portfolio_Value[i,Col_Number_Element_Min] - Min_Difference_Absolute

        # Leftover of monthly contribution

        Monthly_Contribution = Monthly_Contribution - abs(Min_Difference_Absolute)

        #to then search for second largest difference

        Rebalancing_Difference[1,Element_Min] = NA

        Min_Difference = suppressWarnings(min(Rebalancing_Difference,na.rm = TRUE)) #we need to take the max of the negative (i.e. the one where the weight is less than what it should be)

        Element_Min = which(Rebalancing_Difference==suppressWarnings(min(Rebalancing_Difference,na.rm = TRUE)))



        Min_Difference_Absolute = Min_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Min]

        #Now we take the minimum between the left monthly contribution and the available contribution for this asset

        Min_Difference_Absolute = suppressWarnings(min(abs(Min_Difference_Absolute),Monthly_Contribution))

      } # end while loop
    } #end else if Min_Difference_Absolute < Monthly_Contribution

    #Now we add also the withdrawal in case investor's goal = 2

    if (isTRUE(Rebalancing_Input[i,7] >= 65 & Investor_Goal == 2)) {

      Monthly_Withdrawal = ((0.02*(sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Difference_Value)]))/(1-1.02^-(83 - Rebalancing_Input[i,7]))))/12

      #we assume r to be equal to 2%, in line with the 10y rate on US treasury notes

      while (isTRUE(Monthly_Withdrawal > 0)) {

        #We calculate the initial difference to the underweighted asset

        Nrow_Weights <- Weights_Goal[i,1] + 1 #by using Weights goal we automatically use the weights corresponding to the right values for investor's goal and time horizon

        Rebalancing_Difference = Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] - Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

        Max_Difference = suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE))

        Element_Max = which(Rebalancing_Difference==suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE)))

        Col_Number_Element_Max = Element_Max + 1

        Max_Difference_Absolute = Max_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Max]

        Rebalancing_Portfolio_Value[i,Col_Number_Element_Max] = Rebalancing_Portfolio_Value[i,Col_Number_Element_Max] - Max_Difference_Absolute

        # Leftover of monthly contribution

        Monthly_Withdrawal = Monthly_Withdrawal - Max_Difference_Absolute

        #to then search for second largest difference

        Rebalancing_Difference[1,Element_Max] = NA

        Max_Difference = suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE)) #we need to take the max of the positive (i.e. the one where the weight is less than what it should be)

        Element_Max = which(Rebalancing_Difference==suppressWarnings(max(Rebalancing_Difference,na.rm = TRUE)))

        Max_Difference_Absolute = Max_Difference * Rebalancing_Portfolio_Value[i,Col_Number_Element_Max]

        #Now we take the maximum between the left monthly monthly withdrawal and the available contribution for this asset

        Max_Difference_Absolute = suppressWarnings(max(Max_Difference_Absolute,Monthly_Withdrawal))

      } # end while loop
    } # end for loop for withdrawal for a retired investor
  } #end if loop for Rebalancing_Input[i,2]

  Sum_Dividend_Paid = 0 #to reset value for the dividends

  #and we also recalculate the number of shares left for each ETF after monthly contribution and dividends

  Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[i, 2:ncol(Rebalancing_Simulation)],2)

  #Now we do the daily rebalancing, and for this we will need to calculate the portfolio drift as defined by Betterement. if it is >= 3% than we will rebalance, otherwise no.

  #Betterment defines it as the sum of the absolute differences between the optimised weights and the actual weights within the portfolio divided by 2: a level equal to or higher than the drift triggers rebalancing

  #So, let's calculate the portfolio drift, to do it we first need the updated portfolio weights

  Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]/sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

  #Now that we have the updated weights we can calculate the drift as the absolute difference w.r.t. the weights optimised divided by 2

  Nrow_Weights <- Weights_Goal[i,1] + 1
  Actual_Drift = sum(abs(Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] - Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)])/2)

  #Now we chech if the drift is greater or equal to 3%

  if (isTRUE(Actual_Drift >= Drift_Rate)) {

    #since rebalanced is triggered then we calculate the portfolio values as per optimal weights

    Rebalancing_Portfolio_Value_Optimal = sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])*Weights_Optimised_MC[Nrow_Weights,2:ncol(Weights_Optimised_MC)]

    #Now we calculate the difference w.r.t. the values before

    Rebalancing_Difference_Value =  Rebalancing_Portfolio_Value_Optimal - Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]

    #and this are the values of what needs to be sold and bought to rebalance the portfolio.

    #Now we substitute the Rebalancing_Portfolio_Value_Optimal Rebalancing_Portfolio_Value to have the optimal values.

    Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] <- Rebalancing_Portfolio_Value_Optimal

    #And to finish rebalancing we recalculate weights and shares number

    Rebalancing_Weights[i,2:ncol(Rebalancing_Weights)] = Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)]/sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

    Rebalancing_Shares[i,2:ncol(Rebalancing_Shares)] = round(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)] / Rebalancing_Simulation[i, 2:ncol(Rebalancing_Simulation)],2)


  } #end if loop that triggers rebalancing

  Monthly_Contribution = Yearly_Contribution/12

} #end for loop for all the rows




#####################################################################
#####################################################################
########################                    #########################
########################      PART 5_E      #########################
########################                    #########################
#####################################################################
#####################################################################

#Plotting value of Portfolio Overtime and value of single assets overtime

#First we plot single assets:

require(ggplot2)
require(reshape2)

Rebalancing_Portfolio_Value_Melted <- melt(Rebalancing_Portfolio_Value, id.var='Date')

png(filename="Rebalancing_ETFs_Plot.png")

print(ggplot(Rebalancing_Portfolio_Value_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Value in Portfolio') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

dev.off()

print(ggplot(Rebalancing_Portfolio_Value_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Value in Portfolio [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

#Now we can print portfolio value overtime

Total_Portfolio_Value <- data.frame(matrix(nrow=nrow(Rebalancing_Portfolio_Value), ncol = 2 ))

for(i in 1:nrow(Rebalancing_Portfolio_Value)) {

  Total_Portfolio_Value[i,2] =  sum(Rebalancing_Portfolio_Value[i,2:ncol(Rebalancing_Portfolio_Value)])

}

Total_Portfolio_Value[,1] <- Rebalancing_Portfolio_Value[,1]

colnames(Total_Portfolio_Value) <- c("Date", "value")

png(filename="Portfolio_Overtime.png")

print(ggplot(Total_Portfolio_Value, aes(x=Date, y=value)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

dev.off()

print(ggplot(Total_Portfolio_Value, aes(x=Date, y=value)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))




#####################################################################
#####################################################################
########################                    #########################
########################      PART 6_A      #########################
########################                    #########################
#####################################################################
#####################################################################


#This first part of the comparison will relate to downloading historical data for the two ETFs from Vanguard representing the equity and bond market and then, using these to invest in a 70% stock portfolio (most common Betterment portfolio)

#We start by downloading ETF data for Vanguard Total World Stock ETF (VT) and Vanguard Total Bond Market ETF (BND) for the past 5 years

Time <- as.POSIXlt(as.Date(Sys.Date()))
Time$year <- Time$year-5


Start <- as.Date(Time)
End <- as.Date(Sys.Date())


#Now we download the EOD data for each day in the selected period (5 years)

EOD_Data_Vanguard <- data.frame(matrix(nrow=nrow(ETF_EOD_Data), ncol = 2 ))

URL <- paste("https://eodhistoricaldata.com/api/eod/VT?from=" , Start, "&to", End, "&api_token=", api.token, "&period=d&fmt=json", sep="")

Temp <-  fromJSON(getURL(URL)) #Adding Stock Market ETF

EOD_Data_Vanguard[,1] <- Temp[1:nrow(EOD_Data_Vanguard),5]

URL <- paste("https://eodhistoricaldata.com/api/eod/BND?from=" , Start, "&to", End, "&api_token=", api.token, "&period=d&fmt=json", sep="")

Temp <-  fromJSON(getURL(URL)) #Adding Bond Market ETF

EOD_Data_Vanguard[,2] <- Temp[1:nrow(EOD_Data_Vanguard),5]


#Now we move to computing forward looking returns


Returns_Matrix_Vanguard <- data.frame(matrix(nrow=nrow(EOD_Data_Vanguard)-1, ncol=ncol(EOD_Data_Vanguard)))

for (i in 1: 2) {

  Returns_Matrix_Vanguard[,i] <- diff(log(EOD_Data_Vanguard[,i]),lag=1)
}

#To calculate the excess returns:

Returns_Matrix_Vanguard <- Returns_Matrix_Vanguard

colnames(Returns_Matrix_Vanguard) <- c("Equity", "Bond")

#Now we can calculate the shrank Cov Matrix

Cov_Matrix_Vanguard <- cov.shrink(Returns_Matrix_Vanguard)

#Now to calculate the Global Market Portfolio Weights, given the unavailability of these weights on the Betterment Website and the lack on data on a granular level for global market capitalisation for each asset class, we will proceed by calculating the weights based on the market cap of the Equity and Bond market, then this two markets will be further divided to reach the global portfolio weights. A moro thorough explanation of the calculations is available on the Excel "Global_Portfolio_Weights.xlsx"

Weights_Naive_Portfolio <- c(0.70,0.30)

Weights_Naive_Portfolio <- as.data.frame(Weights_Naive_Portfolio)

rownames(Weights_Naive_Portfolio) <- c("Equity", "Bond")

colnames(Weights_Naive_Portfolio) <- "Weights"

#Now we will procees to calculate the returns as done in Thesis_2

#We have the shrank covariance matrix calculated according to Ledoit and Wolf (2003) and we have the weights

#As in Thesis_2 we will use 3.5 as an average estimate of λ

Lambda <- Lambda

# By using CAPM, the expected return is essentially determined to be proportional to the asset’s contribution to the overall portfolio risk. (cit.Betterment)

Forward_Looking_Returns_Vanguard <- Lambda * Cov_Matrix_Vanguard * Weights_Naive_Portfolio
colnames(Forward_Looking_Returns_Vanguard) <- "Forward_Looking_Returns"



#####################################################################
#####################################################################
########################                    #########################
########################      PART 6_B      #########################
########################                    #########################
#####################################################################
#####################################################################



#Now we proceed to estimating the returns based on the views on the market. To do this we will implement the Black Litterman model. However, to keep the objectivity needed to run this code autonomously we will proceed by estimating the views on the assets through an ARMA-eGarch model

#We can then move on to forecast our views

#We will use the eGarch model for the volatility forecast and for the mean model we first need to see whether the time series are stationary, in which case we use the ARMA model or not.

ADF_PValue_Vanguard <- data.frame(matrix(nrow=nrow(Weights_Naive_Portfolio), ncol=2))

for(i in 1:nrow(ADF_PValue_Vanguard)) {

  acf(ETF_EOD_Data[,i], lag.max = 1000)

  acf(Returns_Matrix[,i], lag.max = 1000)

  temp <- adf.test(ETF_EOD_Data[,i])

  ADF_PValue_Vanguard[i,1] <- temp$p.value[1]

}

# Then, since the time series are all non-stationary we difference them once

Diff_Time_Series_Vanguard <- data.frame(matrix(nrow=nrow(ETF_EOD_Data)-1, ncol=nrow(Weights_Naive_Portfolio)))

for(i in 1:nrow(Weights_Naive_Portfolio)) {

  Diff_Time_Series_Vanguard[,i] <- diff(EOD_Data_Vanguard[,i], differences=1)

  temp <- adf.test(Diff_Time_Series_Vanguard[,i])

  ADF_PValue_Vanguard[i,2] <- temp$p.value[1]

}

#Now that we reached stationarity in all the times series (p-value smaller than 0.01 in each of them) we know that we will use an ARIMA model.

#To do this we first estimate the best p,q for the model based on information criteria

LogL <- matrix(0,nrow=3,ncol=3)
Params <- matrix(0,nrow=3,ncol=3)
Aic_Vanguard <- matrix(0,nrow=3,ncol=3)
Control = list(RHO = 1,DELTA = 1e-8,MAJIT = 100,MINIT = 650,TOL = 1e-6)

PQ_Matrix_Vanguard = matrix(0,nrow=nrow(Weights_Naive_Portfolio),ncol=2)
suppressWarnings(
  for(i in 1 : nrow(Weights_Naive_Portfolio)) {
    for (p in 1:3) {
      for (q in 1:3) {
        spec <- ugarchspec(mean.model=list(armaOrder=c(p,1,q)),variance.model=list(model = "eGARCH",garchOrder=c(1,1)))
        fit <- ugarchfit(spec=spec,data= Returns_Matrix_Vanguard[,i],solver = "hybrid", solver.control = Control)
        LogL[p,q] <- likelihood(fit)
        Params[p,q] <- length(coef(fit))
        Aic_Vanguard[p,q] <- infocriteria(fit)[1]

        #Now we choose and input the best p,q for each of the selected ETFs in the PQ_Matrix
        Indices = which(Aic_Vanguard == min(Aic_Vanguard), arr.ind=TRUE)
        PQ_Matrix_Vanguard[i,1] = Indices[1,1]
        PQ_Matrix_Vanguard[i,2] = Indices[1,2]
      }
    }
  }
)

Mean_Estimate_Vanguard = matrix(0,nrow=nrow(Weights_Naive_Portfolio),ncol=1)
Vola_Estimate_Vanguard = matrix(0,nrow=nrow(Weights_Naive_Portfolio),ncol=1)

for(i in 1:nrow(Weights_Naive_Portfolio)) {

  spec <- ugarchspec(mean.model=list(armaOrder=c(PQ_Matrix[i,1],1,PQ_Matrix[i,2])),variance.model=list(model = "eGARCH",garchOrder=c(1,1)))

  fit <- ugarchfit(spec=spec,data= Returns_Matrix[,i],solver = "hybrid", solver.control = Control)

  #Now that we have the mean forecast for the daily return we can convert it to yearly return and then compute our views based on that

  eGarch_Forecast <- ugarchforecast(fit,n.ahead = 252)
  Mean_Estimate_Vanguard[i] <- mean(fitted(eGarch_Forecast))
  Vola_Estimate_Vanguard[i] <- mean(sigma(eGarch_Forecast))
}

Mean_Estimate_Vanguard <- as.data.frame(Mean_Estimate_Vanguard) - Daily_Risk_Free_Rate

rownames(Mean_Estimate_Vanguard) = rownames(Weights_Naive_Portfolio)

#Now we move to formatting the views in such a way that they can be used as input in the Black-Litterman model.

#Given that the views that we express are absolute, we are going to input 1 in each row (view) in the column corresponding to the respective asset. Therefore, the P matrix will be equal to the identity matrix

P_Matrix_Vanguard = diag(2)

colnames(P_Matrix_Vanguard) <- rownames(Weights_Naive_Portfolio)

#Now we move to calculating the variances for each of the individual portfolios (views). This will be done through pk Σpk' where pk is the 1xN vector of the kth view and Σ is the covariance matrix of excess returns

Individual_Variances_Vanguard <- matrix(0,nrow=nrow(Weights_Naive_Portfolio),ncol=1)

for(i in 1: nrow(Weights_Naive_Portfolio)) {

  Individual_Variances_Vanguard[i] = t(P_Matrix_Vanguard[i,])%*%Cov_Matrix_Vanguard%*%P_Matrix_Vanguard[i,]


}


#Now we move to calculating the scalar tau, a parameter that is inversely proportional to the level of confidence expressed in the views

#He and Litterman (1999) calibrate the confidence of a view so that the ratio of ω τ is equal to the variance of the view portfolio ( pk Σpk' ). Assuming τ = 0.025 and using the individual variances of the view portfolios ( pk Σpk' )

#When the covariance matrix of the error term ( Ω ) is calculated using this method, the actual value of the scalar (τ ) becomes irrelevant because only the ratio ω /τ enters the model. For example, changing the assumed value of the scalar (τ ) from 0.025 to 15 dramatically changes the value of the diagonal elements of Ω , but the new Combined Return Vector ( E[R]) is unaffected.



Tau = 0.03

Cov_Matrix_Error_Term_Vanguard = matrix(0,nrow=nrow(Weights_Naive_Portfolio),ncol=nrow(Weights_Naive_Portfolio))

for(i in 1:nrow(Weights_Naive_Portfolio)) {


  Cov_Matrix_Error_Term_Vanguard[i,i] = Tau * Individual_Variances_Vanguard[i]

}

#He and Litterman (1999) and Litterman (2003) suggest that, in the presence of constraints, the investor input the New Combined Return Vector ( E[R]) into a mean-variance optimizer.


# Bevan and Winkelmann (1998) offer guidance in setting the weight given to the View Vector (Q). After deriving an initial Combined Return Vector (E[R]) and the subsequent optimum portfolio weights, they calculate the anticipated Information Ratio of the new portfolio. They recommend a maximum anticipated Information Ratio of 2.0. If the Information Ratio is above 2.0, decrease the weight given to the views (decrease the value of the scalar and leave the diagonal elements of Ω unchanged).

# We now compute the combined return vector as:E[R]=[(τΣ)^-1 +P'Ω P]^-1[(τΣ)^-1 Π+P'Ω Q]

Combined_Return_Vector_Vanguard =  inv(inv(Tau*Cov_Matrix_Vanguard) + P_Matrix_Vanguard * inv(Cov_Matrix_Error_Term_Vanguard) * P_Matrix_Vanguard) * (inv(Tau*Cov_Matrix_Vanguard)*Forward_Looking_Returns_Vanguard + P_Matrix_Vanguard * inv(Cov_Matrix_Error_Term_Vanguard) * Mean_Estimate_Vanguard)





#####################################################################
#####################################################################
########################                    #########################
########################      PART 6_C      #########################
########################                    #########################
#####################################################################
#####################################################################


#Now that we have forward looking returns we apply MC_Simulation also here to produce a robust estimate for the forecast of the Vanguard's ETFs

Years <- Years # We assume a forecast period of 5 years
Trading_Days_Year <- 252
Time = round(Years * Trading_Days_Year, digits = 0)
Delta <- 1 / Trading_Days_Year
Simulations <- Simulations #We simulate 1000 times the stock price movement

#Create Date Column with trading days to add to each MC Simulation

Starting_Date <- End
End_Date <- Starting_Date + (365*40)
holidays = holidayNYSE()
Seq_Days = as.timeDate(seq(from = Starting_Date, to = End_Date, by = "day"))
Seq_Days <- Seq_Days[isBizday(Seq_Days, holidays = holidays, wday = 1:5)]
Seq_Days <- Seq_Days[1:nrow(Stock_Prices)]
Seq_Days <- as.data.frame(Seq_Days)

n <- (nrow(Forward_Looking_Returns_Vanguard)+1) #number of columns to insert data into array

#Creating the Matrix for each simulation

Stock_Prices_Vanguard <- data.frame(matrix(nrow=Time + 1, ncol = Simulations ))
Stock_Prices_Vanguard <- cbind(Seq_Days[1:nrow(Stock_Prices_Vanguard),1], Stock_Prices_Vanguard)
colnames(Stock_Prices_Vanguard)[1] = "Date"

#Creating a 3 dimensional array to keep the simulations for future rebalancing in Part 5

Array_Stock_Prices_MC_Vanguard <-array(0,dim=c(nrow(Stock_Prices_Vanguard),nrow(Forward_Looking_Returns_Vanguard)+1,ncol(Stock_Prices_Vanguard)-1))

#Create dataframes for Average return and forward return

Average_Daily_Return_Vanguard <- data.frame(matrix(nrow=2, ncol = 1 ))
Forward_Return_Vanguard <- data.frame(matrix(nrow=2, ncol = 1 ))
BL_Return_Vanguard <- data.frame(matrix(nrow=2, ncol = 1 ))

set.seed(153) # to make the program reproducible #123

system.time({
  for (i in 1: nrow(Forward_Looking_Returns_Vanguard)) {
    for (k in 1 : Simulations) {

      Stock_Prices_Vanguard[1,2:ncol(Stock_Prices_Vanguard)] <- EOD_Data_Vanguard[nrow(EOD_Data_Vanguard),i]

      Average_Daily_Return_Vanguard[i,1] <- (1+mean(Returns_Matrix_Vanguard[,i], na.rm = TRUE))^Trading_Days_Year - 1

      Forward_Return_Vanguard[i,1] <- (1+Forward_Looking_Returns_Vanguard[i,1])^Trading_Days_Year - 1

      BL_Return_Vanguard[i,1] <- (1+Combined_Return_Vector_Vanguard[i,1])^Trading_Days_Year - 1

      Variance_Vanguard <- Cov_Matrix_Vanguard[i,i]*sqrt(Trading_Days_Year)

      Array_Stock_Prices_MC_Vanguard[,1,k] <- Seq_Days[1:(Time+1),1]

      Array_Stock_Prices_MC_Vanguard[1,i+1,k] <- EOD_Data_Vanguard[nrow(EOD_Data_Vanguard),i]


      for (j in 1: Time) {

        Stock_Prices_Vanguard[j+1,k+1] = Stock_Prices_Vanguard[j,k+1] * exp((BL_Return_Vanguard[i,1]-0.5*sqrt(Variance_Vanguard))*Delta+sqrt(Variance_Vanguard)*Z[j+Simulations*(k-1)+Simulations*Time*(i-1)]*sqrt(Delta))

        Array_Stock_Prices_MC_Vanguard[j+1,i+1,k] <- Stock_Prices_Vanguard[j+1,k+1]

      }}

    require(ggplot2)
    require(reshape2)
    Stock_Prices_Vanguard_Melted <- melt(Stock_Prices_Vanguard, id.var='Date')

    Plot_Name <- paste("MC_Vanguard", colnames(ETF_EOD_Data[i]), ".png", sep = "")

    png(filename=Plot_Name)

    print(ggplot(Stock_Prices_Vanguard_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Price') + theme_minimal() + theme(legend.position = "none") + scale_color_brewer(palette = "RdBu"))

    dev.off()

    Dataframe_Name <- paste("MC_Vanguard_", colnames(EOD_Data_Vanguard[i]), sep = "")
    assign(Dataframe_Name, Stock_Prices_Vanguard)

  }

})

#Now we create a Price evolution from the average of the prices in the MC method

Average_MC_Vanguard <- data.frame(matrix(nrow=length(Array_Stock_Prices_MC_Vanguard[,1,1])), ncol=ncol(EOD_Data_Vanguard))

for(j in 1:length(Array_Stock_Prices_MC_Vanguard[,1,1])) {
  for(i in 1:Simulations) {
    for(k in 1:nrow(Forward_Looking_Returns_Vanguard)) {

      Average_MC_Vanguard[j,k] <- median(Array_Stock_Prices_MC_Vanguard[j,k+1,i])

    }}}

#Let's plot these prices:

require(ggplot2)
require(reshape2)

Average_MC_Vanguard <- cbind(`MC_Bond Emerging`[1:nrow(Average_MC_Vanguard),1] ,Average_MC_Vanguard)

colnames(Average_MC_Vanguard)[1] = "Date"

colnames(Average_MC_Vanguard)[2:3] = rownames(Forward_Looking_Returns_Vanguard)

Average_MC_Melted_Vanguard <- melt(Average_MC_Vanguard, id.var='Date')

png(filename="Average_MC_Vanguard.png")

print(ggplot(Average_MC_Melted_Vanguard, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Stock Price') + theme_minimal())

dev.off()

print(ggplot(Average_MC_Melted_Vanguard, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Price') + theme_minimal() )





#####################################################################
#####################################################################
########################                    #########################
########################      PART 6_D      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now we create the portfolio values overtime for each simulation and then we put them in increasing order for w.r.t. the end value. The weights used are the weights of the market portfolio

Portfolio_Value_Overtime_MC_Vanguard <- data.frame(matrix(nrow=length(Array_Stock_Prices_MC_Vanguard[,1,1]), ncol=Simulations))

for(i in 1:Simulations) {
  for(j in 1:length(Array_Stock_Prices_MC_Vanguard[,1,1])) {

    Portfolio_Value_Overtime_MC_Vanguard[j,i] = sum(Array_Stock_Prices_MC_Vanguard[j,2:3,i]*Weights_Naive_Portfolio*Initial_Investment/Array_Stock_Prices_MC_Vanguard[1,2:3,i])


  }}

Portfolio_Value_Overtime_MC_Vanguard <- Portfolio_Value_Overtime_MC_Vanguard[,order(Portfolio_Value_Overtime_MC_Vanguard[nrow(Portfolio_Value_Overtime_MC_Vanguard),])]

Portfolio_Value_Overtime_MC_Quantile_Vanguard <- Portfolio_Value_Overtime_MC_Vanguard[,c(1,ceiling(0.01*Simulations),ceiling(0.05*Simulations),ceiling(0.10*Simulations),ceiling(0.25*Simulations),ceiling(0.50*Simulations),ceiling(0.75*Simulations),ceiling(0.90*Simulations),ceiling(0.95*Simulations),ceiling(0.99*Simulations),Simulations)]

Portfolio_Value_Overtime_MC_Quantile_Vanguard <- Portfolio_Value_Overtime_MC_Quantile_Vanguard[,order(Portfolio_Value_Overtime_MC_Quantile_Vanguard[nrow(Portfolio_Value_Overtime_MC_Quantile_Vanguard),])]

Portfolio_Value_Overtime_MC_Quantile_Vanguard <- cbind(Seq_Days[,1],Portfolio_Value_Overtime_MC_Quantile_Vanguard)

#Let's plot these portfolio values:

require(ggplot2)
require(reshape2)

colnames(Portfolio_Value_Overtime_MC_Quantile_Vanguard)[1] = "Date"
colnames(Portfolio_Value_Overtime_MC_Quantile_Vanguard)[2:12] <- c("Min", "1%", "5%", "10%", "25%", "50%", "75%", "90%", "95%", "99%", "Max")

Portfolio_Value_Overtime_MC_Quantile_Vanguard_Melted <- melt(Portfolio_Value_Overtime_MC_Quantile_Vanguard, id.var='Date')

png(filename="Portfolio_Value_Overtime_MC_Vanguard.png")

print(ggplot(Portfolio_Value_Overtime_MC_Quantile_Vanguard_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Naive Portfolio Overtime MC Simulations') + theme_minimal())

dev.off()

print(ggplot(Portfolio_Value_Overtime_MC_Quantile_Vanguard_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Naive Portfolio Overtime MC Simulations') + theme_minimal())

#Now we produce some statistics on the Portfolio return:

Yearly_Portfolio_Return_Vanguard = as.numeric((Portfolio_Value_Overtime_MC_Vanguard[nrow(Portfolio_Value_Overtime_MC_Vanguard),]/Portfolio_Value_Overtime_MC_Vanguard[1,])^(1/Years) - 1)

plot((Yearly_Portfolio_Return_Vanguard))

#Let's fill the previously created matrix with values from this portfolio

Portfolio_Returns_Moments[1,3] = mean(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[2,3] = sd(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[3,3] = skewness(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[4,3] = kurtosis(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE, method = "moment")


Portfolio_Returns_Moments[5,3] = median(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[6,3] = min(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[7,3] = max(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[8,3] = IQR(Yearly_Portfolio_Return_Vanguard,na.rm = TRUE)


Portfolio_Returns_Moments[9,3] = jarque.bera.test(Yearly_Portfolio_Return_Vanguard)


Portfolio_Returns_Moments[10,3] = sharpe(Yearly_Portfolio_Return_Vanguard, r = 0, scale = sqrt(1))


Portfolio_Returns_Moments[11,3] = quantile(Yearly_Portfolio_Return_Vanguard, 0.05)


Portfolio_Returns_Moments[12,3] = quantile(Yearly_Portfolio_Return_Vanguard, 0.01)

Portfolio_Returns_Moments[13,3] <- mean(Yearly_Portfolio_Return[Yearly_Portfolio_Return<=quantile(Yearly_Portfolio_Return_Vanguard, 0.05)])

Portfolio_Returns_Moments[14,3] <- mean(Yearly_Portfolio_Return[Yearly_Portfolio_Return<=quantile(Yearly_Portfolio_Return_Vanguard, 0.01)])


rownames(Portfolio_Returns_Moments) <- c("Mean return p.a. (%)", "SD p.a. (%)", "Skewness", "Kurtosis", "Median p.a. (%)", "Min", "Max", "IQR", "JB-stat", "Sharpe Ratio", "VaR 5%", "VaR 1%", "ES 5%", "ES 1%")

colnames(Portfolio_Returns_Moments) <- c("Market Portfolio","Sustainable Market Portfolio","Naive Portfolio")




#####################################################################
#####################################################################
########################                    #########################
########################      PART 6_E      #########################
########################                    #########################
#####################################################################
#####################################################################

#Now that we have produced the estimate we compute the overall portfolio value for a naive portfolio where we only take into account simple reinvestment in the same ETF of dividends and deduction of fee, no rebalancing is done on such a portfolio


# Now that the goals have been set, we move on to forecasting the rebalancing of the portfolio on a daily basis.

# As a first step we create a dataframe with the time horizon of the investment for the investor and then we fill it in step-by-step with our inputs

Rebalancing_Input_Vanguard <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 5 ))
Rebalancing_Input_Vanguard[,1] <- Seq_Days[,1]
colnames(Rebalancing_Input_Vanguard)[1] = "Date"


# Now we create:

# in the second column a Yes/No vector which says if the day is the last business day of the month;

# a third column which says whether this is the last day of the quarter

# a fourth column with the fee from Vanguard's Equity ETF

# a fifth column with the fee from Vanguard's Bond ETF

Vanguard_ETFs <- subset(Etf_Complete_Matrix, Code == "VT" | Code == "BND")

for(i in 1: nrow(Rebalancing_Input_Vanguard)) {

  #Second column

  if (isTRUE(months.Date(Rebalancing_Input_Vanguard[i,1]) != months.Date(Rebalancing_Input_Vanguard[i+1,1]))) {Rebalancing_Input_Vanguard[i,2] = "Yes"}

  #Third column

  if (isTRUE(quarters.Date(Rebalancing_Input_Vanguard[i,1]) != quarters.Date(Rebalancing_Input_Vanguard[i+1,1]))) {Rebalancing_Input_Vanguard[i,3] = "Yes"}

  #Adding Vanguard's Equity Fee every quarter in a fourth column

  if (isTRUE(Rebalancing_Input_Vanguard[i,3] == "Yes")) {Rebalancing_Input_Vanguard[i,4] = 1 - (Vanguard_ETFs$NetExpenseRatio[2])/4}

  #Adding Vanguard's Bond Fee every quarter in a fourth column

  if (isTRUE(Rebalancing_Input_Vanguard[i,3] == "Yes")) {Rebalancing_Input_Vanguard[i,5] = 1 - (Vanguard_ETFs$NetExpenseRatio[1])/4}

}

colnames(Rebalancing_Input_Vanguard)[2:5] = c("End of Month", "End of Quarter","Equity Fee", "Bond Fee")

#Now we take the dividend yield for Vanguard's ETFs
Dividend_Yield_Vanguard = as.numeric(Vanguard_ETFs$Yield)
Dividend_Yield_Vanguard = 1 + Dividend_Yield_Vanguard/12
#Now we turn to rebalancing and we will use the average that we calculated as a possible evolution of prices

Rebalancing_Simulation_Vanguard <- Average_MC_Vanguard

Rebalancing_Simulation_Vanguard <- as.data.frame(Rebalancing_Simulation_Vanguard)

colnames(Rebalancing_Simulation_Vanguard) <- rownames(Forward_Looking_Returns_Vanguard)

colnames(Rebalancing_Simulation_Vanguard)[1] = "Date"

Rebalancing_Simulation_Vanguard[,1] <- Rebalancing_Input_Vanguard[1:nrow(Rebalancing_Simulation_Vanguard),1]


#Now we create the dataframe where we have the exact amount invested in each ETF

Rebalancing_Portfolio_Value_Vanguard <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 3 ))

Rebalancing_Portfolio_Value_Vanguard[,1] <- Rebalancing_Input_Vanguard[,1]

colnames(Rebalancing_Portfolio_Value_Vanguard)[1] <- "Date"

colnames(Rebalancing_Portfolio_Value_Vanguard)[2:3] <- rownames(Forward_Looking_Returns_Vanguard)

#Now we fill the first row of the dataframe with the initial value of each asset class

Weights_Naive_Portfolio <- t(Weights_Naive_Portfolio)
Rebalancing_Portfolio_Value_Vanguard[1,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] <- round(Initial_Investment*Weights_Naive_Portfolio,2)

#Now we create the dataframe with the amounch of "shares" in each etf, we will round to 2 decimals as Betterment explicitly says they use fractional shares

Rebalancing_Shares_Vanguard <- data.frame(matrix(nrow= nrow(Seq_Days), ncol = 3 ))

Rebalancing_Shares_Vanguard[,1] <- Rebalancing_Input_Vanguard[,1]

colnames(Rebalancing_Shares_Vanguard)[1] <- "Date"

colnames(Rebalancing_Shares_Vanguard)[2:3] <- rownames(Forward_Looking_Returns_Vanguard)

#and we fill it in with the different shares by dividing portfolio value by prices of single ETFs

Rebalancing_Shares_Vanguard[1,2:ncol(Rebalancing_Shares_Vanguard)] = round(Rebalancing_Portfolio_Value_Vanguard[1,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] / Rebalancing_Simulation_Vanguard[1, 2:ncol(Rebalancing_Simulation_Vanguard)],2)


#Now that we have prepared all the necessary inputs and dataframes we can move to deducting the fee and adding the dividends for this portfolio

for (i in 2:nrow(Rebalancing_Simulation_Vanguard)) {

  #First we recalculate the portfolio value and the weights based on the new prices

  Rebalancing_Shares_Vanguard[i,2:ncol(Rebalancing_Shares_Vanguard)] = Rebalancing_Shares_Vanguard[i-1,2:ncol(Rebalancing_Shares_Vanguard)]

  Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] = Rebalancing_Shares_Vanguard[i,2:ncol(Rebalancing_Shares_Vanguard)] * Rebalancing_Simulation_Vanguard[i,2:ncol(Rebalancing_Simulation_Vanguard)]

  if (isTRUE(Rebalancing_Input_Vanguard[i,3] == "Yes")) {

    #first we deduct Vanguard's fee at the end of every quarter

    Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] = Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] * Rebalancing_Input_Vanguard[i,4:5]

    #and we also recalculate the number of shares left for each ETF after these 2 fees

    Rebalancing_Shares_Vanguard[i,2:ncol(Rebalancing_Shares_Vanguard)] = round(Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] / Rebalancing_Simulation_Vanguard[i, 2:ncol(Rebalancing_Simulation_Vanguard)],2)

    #We add the dividends that are paid by the ETFs

    Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] = Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] * Dividend_Yield_Vanguard

  } # end if loop for Rebalancing_Input[i,3]

  #and we also recalculate the number of shares left for each ETF after monthly contribution and dividends

  Rebalancing_Shares_Vanguard[i,2:ncol(Rebalancing_Shares_Vanguard)] = round(Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)] / Rebalancing_Simulation_Vanguard[i, 2:ncol(Rebalancing_Simulation_Vanguard)],2)

} #end for loop for all the rows

#Plotting value of Portfolio Overtime and value of single assets overtime

#First we plot single assets:

require(ggplot2)
require(reshape2)

Rebalancing_Portfolio_Value_Vanguard_Melted <- melt(Rebalancing_Portfolio_Value_Vanguard, id.var='Date')

png(filename="Rebalancing_Vanguard.png")

print(ggplot(Rebalancing_Portfolio_Value_Vanguard_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Value in Portfolio') + theme_minimal())

dev.off()

print(ggplot(Rebalancing_Portfolio_Value_Vanguard_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('ETF Value in Portfolio [USD]') + theme_minimal())

#Now we can print portfolio value overtime

Total_Portfolio_Value_Vanguard <- data.frame(matrix(nrow=nrow(Rebalancing_Portfolio_Value_Vanguard), ncol = 2 ))

for(i in 1:nrow(Rebalancing_Portfolio_Value_Vanguard)) {

  Total_Portfolio_Value_Vanguard[i,2] =  sum(Rebalancing_Portfolio_Value_Vanguard[i,2:ncol(Rebalancing_Portfolio_Value_Vanguard)])

}

Total_Portfolio_Value_Vanguard[,1] <- Rebalancing_Portfolio_Value_Vanguard[,1]

colnames(Total_Portfolio_Value_Vanguard) <- c("Date", "value")

png(filename="Portfolio_Overtime.png")

print(ggplot(Total_Portfolio_Value_Vanguard, aes(x=Date, y=value)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))

dev.off()

print(ggplot(Total_Portfolio_Value_Vanguard, aes(x=Date, y=value)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal() + scale_color_brewer(palette = "RdBu"))




#####################################################################
#####################################################################
########################                    #########################
########################      PART 6_F      #########################
########################                    #########################
#####################################################################
#####################################################################


#Now we finish up by plotting the values of the 2 portfolios, the one with 11 ETFs and the one composed by only 2 ETFs without robo-advisory allocation to see their evolvement overtime

Total_Portfolio_Comparison <- cbind(Total_Portfolio_Value_Vanguard,Total_Portfolio_Value[1:nrow(Total_Portfolio_Value_Vanguard),2])

colnames(Total_Portfolio_Comparison)[2:3] <- c("Vanguard", "Betterment")

require(ggplot2)
require(reshape2)

Portfolio_Comparison_Melted <- melt(Total_Portfolio_Comparison, id.var='Date')

png(filename="Portfolio_Comparison.png")

print(ggplot(Portfolio_Comparison_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Portfolio Value') + theme_minimal())

dev.off()

print(ggplot(Portfolio_Comparison_Melted, aes(x=Date, y=value, col=variable)) + geom_line() + xlab('Year') + ylab('Portfolio Value [USD]') + theme_minimal())

print("Comparison concluded successfully")

}

remove(a, Dividend_Paid, Dividend_Yield, Bond_Emerging, Bond_High_Quality, Bond_International, Bond_TIPS,
       Bond_Treasuries,Equity_Emerging, Equity_International, Equity_US_Small, Equity_US_Mid, Equity_US_Large, Equity_US_Total,
       Actual_Drift, Age_Investor_End, api.token, Bond_Level, Bond_Max, Bond_Min, Col_Number_Element_Min, Control,
       Dataframe_Name, Delta, Dividend_Yield_Vanguard, Drift_Rate, eGarch_Forecast, Element_Min,
       End, End_Date, End_Date_Investment, Fee, fit, holidays, i, id, j, k, l, Min_Difference,
       Min_Difference_Absolute, Monthly_Contribution, n, Nrow_Weights, opt_minvar, p, Plot_Name, q, spec, Start, Starting_Date,
       Stock_Level, Stock_Max, Stock_Min, Sum_Dividend_Paid, temp, Time, Time_Horizon, Trading_Days_Year,Treasuries_Max, Treasuries_Min,
       URL, Weight_Sim, Yearly_Contribution, Yearly_Portfolio_Return, Yearly_Portfolio_Return_Vanguard, Years_To_Investment, Z)

#Lastly we save the entire environment in the directory

Portfolio_Value_Vanguard <- Rebalancing_Portfolio_Value_Vanguard

Variables_To_Keep <- c("Array_Stock_Prices_MC","Selected_ETFs","Etf_Complete_Matrix",
                       "Weights_Optimised_MC","Rebalancing_Portfolio_Value",
                       "Array_Stock_Prices_MC_Vanguard", "Rebalancing_Portfolio_Value_Vanguard",
                       "EOD_Data_MC", "EOD_Data_Vanguard", "Portfolio_Value_Vanguard",
                       "Years", "Simulations","Investor_Goal","Age_Investor",
                       "Initial_Investment","Yearly_Contribution","Sustainable","Lambda","Comparison")

rm(list=setdiff(ls(), Variables_To_Keep))

List_To_Export <- mget(ls())

return(List_To_Export)

}

